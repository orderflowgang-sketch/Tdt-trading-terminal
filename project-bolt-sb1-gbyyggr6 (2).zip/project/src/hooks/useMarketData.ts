// ============================================================
// Market Data Hook — manages candle fetching and state
// ============================================================

import { useState, useEffect, useCallback, useRef } from 'react';
import { Candle, Timeframe } from '@/types';
import { fetchCandles, fetchMultiTimeframe, fetchHistoricalCandles } from '@/market/twelveData';

interface MarketDataState {
  loading: boolean;
  error: string | null;
  candles15m: Candle[];
  candles4h: Candle[];
  candles1d: Candle[];
  candles1w: Candle[];
  lastUpdate: number | null;
}

const initialState: MarketDataState = {
  loading: true,
  error: null,
  candles15m: [],
  candles4h: [],
  candles1d: [],
  candles1w: [],
  lastUpdate: null,
};

export function useMarketData(symbol: string, timeframe: Timeframe) {
  const [state, setState] = useState<MarketDataState>(initialState);
  const refreshTimer = useRef<ReturnType<typeof setInterval> | null>(null);

  const load = useCallback(async () => {
    setState((prev) => ({ ...prev, loading: true, error: null }));
    try {
      const data = await fetchMultiTimeframe(symbol, 200);
      setState({
        loading: false,
        error: null,
        candles15m: data['15m'],
        candles4h: data['4h'],
        candles1d: data['1day'],
        candles1w: data['1week'],
        lastUpdate: Date.now(),
      });
    } catch (err) {
      setState((prev) => ({
        ...prev,
        loading: false,
        error: err instanceof Error ? err.message : 'MARKET DATA UNAVAILABLE',
      }));
    }
  }, [symbol]);

  useEffect(() => {
    load();
    // Auto-refresh every 60 seconds
    if (refreshTimer.current) clearInterval(refreshTimer.current);
    refreshTimer.current = setInterval(load, 60_000);
    return () => {
      if (refreshTimer.current) clearInterval(refreshTimer.current);
    };
  }, [load]);

  return { ...state, refresh: load };
}

/**
 * Hook for loading historical data for a specific date range.
 */
export function useHistoricalData(symbol: string, date: Date, timezone: string) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [candles15m, setCandles15m] = useState<Candle[]>([]);
  const [candles4h, setCandles4h] = useState<Candle[]>([]);
  const [candles1d, setCandles1d] = useState<Candle[]>([]);
  const [candles1w, setCandles1w] = useState<Candle[]>([]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    (async () => {
      try {
        // Build date range: 3 days before to 2 days after the target date
        const start = new Date(date);
        start.setDate(start.getDate() - 3);
        const end = new Date(date);
        end.setDate(end.getDate() + 2);

        const startStr = start.toISOString().slice(0, 10);
        const endStr = end.toISOString().slice(0, 10);

        const [m15, h4, d1, w1] = await Promise.all([
          fetchHistoricalCandles(symbol, '15min', startStr, endStr, 500),
          fetchHistoricalCandles(symbol, '4h', startStr, endStr, 200),
          fetchHistoricalCandles(symbol, '1day', startStr, endStr, 50),
          fetchHistoricalCandles(symbol, '1week', startStr, endStr, 30),
        ]);

        if (cancelled) return;

        setCandles15m(m15);
        setCandles4h(h4);
        setCandles1d(d1);
        setCandles1w(w1);
        setLoading(false);
      } catch (err) {
        if (cancelled) return;
        setError(err instanceof Error ? err.message : 'MARKET DATA UNAVAILABLE');
        setLoading(false);
      }
    })();

    return () => { cancelled = true; };
  }, [symbol, date.toISOString().slice(0, 10), timezone]);

  return { loading, error, candles15m, candles4h, candles1d, candles1w };
}

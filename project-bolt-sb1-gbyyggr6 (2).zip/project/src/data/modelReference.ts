// ============================================================
// Model reference data for the Models screen
// Updated for 02:00 SAST anchored node mapping.
// Node 1 = 02:00 SAST, Node 12 = 13:00, Node 20 = 21:00, etc.
// ============================================================

export interface RootMappingDisplay {
  root: number;
  ratio: string;
  node: number;
  sastTime: string;
  type: string;
  description: string;
}

export interface DateEventDisplay {
  dateNumber: number;
  eventType: string;
  node: number;
  sastTime: string;
  directionRuleLabel: string;
  description: string;
}

export const ROOT_MAPPINGS_LIST: RootMappingDisplay[] = [
  {
    root: 1,
    ratio: '1:6',
    node: 6,
    sastTime: '07:00',
    type: 'Model 1',
    description: 'Root 1 expansion day. Model 1 event at Node 6 (07:00 SAST). Direction determined by confirmed 4H MSS.',
  },
  {
    root: 3,
    ratio: '3:12',
    node: 12,
    sastTime: '13:00',
    type: 'Model 1',
    description: 'Root 3 expansion day. Primary Model 1 event at Node 12 (13:00 SAST). Has a continuation at 3:13 (Node 13, 14:00 SAST) which is a 7-sum event.',
  },
  {
    root: 5,
    ratio: '5:17',
    node: 17,
    sastTime: '18:00',
    type: 'Model 1',
    description: 'Root 5 expansion day. Model 1 event at Node 17 (18:00 SAST). Represents a retracement peak after a 4H MSS. Direction taken from that confirmed MSS.',
  },
  {
    root: 7,
    ratio: '7:12',
    node: 12,
    sastTime: '13:00',
    type: 'Model 1',
    description: 'Root 7 expansion day. Model 1 event at Node 12 (13:00 SAST). Do NOT confuse with Date 7 / Node 3 (04:00 SAST) which is a completely different concept.',
  },
  {
    root: 9,
    ratio: '9:9',
    node: 9,
    sastTime: '10:00',
    type: 'Early Expansion',
    description: 'Root 9 expansion day. Early expansion at Node 9 (10:00 SAST). Direction determined by confirmed 4H MSS.',
  },
];

export const DATE_EVENTS_LIST: DateEventDisplay[] = [
  {
    dateNumber: 1,
    eventType: 'Node 6→7 Entry',
    node: 7,
    sastTime: '08:00',
    directionRuleLabel: 'MSS Direction',
    description: 'Node 6 close → Node 7 entry. Direction taken from confirmed 4H MSS. Bullish 4H MSS → BUY. Bearish 4H MSS → SELL. No confirmed MSS → WAITING FOR CONFIRMATION.',
  },
  {
    dateNumber: 3,
    eventType: '7-Sum Event',
    node: 13,
    sastTime: '14:00',
    directionRuleLabel: 'MSS Direction',
    description: '3:13 is a 7-sum event. Direction taken from confirmed 4H MSS. Bullish → BUY. Bearish → SELL.',
  },
  {
    dateNumber: 4,
    eventType: '7-Sum Counter-Trend Sweep',
    node: 13,
    sastTime: '14:00',
    directionRuleLabel: 'Counter-Trend',
    description: '4:13 is a 7-sum sweep. Date 4 is even and opposes the directional HTF trend. Bullish HTF direction → SELL. Bearish HTF direction → BUY. Only trigger after the sweep confirmation.',
  },
  {
    dateNumber: 5,
    eventType: 'Retracement Peak',
    node: 17,
    sastTime: '18:00',
    directionRuleLabel: 'MSS Direction',
    description: '5:17 is a retracement peak after a 4H MSS. Take the direction of that particular confirmed MSS. Bullish MSS → BUY. Bearish MSS → SELL.',
  },
  {
    dateNumber: 6,
    eventType: 'Continuation',
    node: 17,
    sastTime: '18:00',
    directionRuleLabel: 'Preserve Date 5',
    description: 'Continuation of Date 5. Preserve Date 5 directional context. Do not invent a new unrelated direction.',
  },
  {
    dateNumber: 7,
    eventType: 'MSS Retest',
    node: 3,
    sastTime: '04:00',
    directionRuleLabel: 'MSS Direction',
    description: 'Date 7 Model 1 event = Node 3 (04:00 SAST). This is a retest of a 4H MSS. Trade the retest in the direction of that confirmed MSS. IMPORTANT: Do NOT confuse Date 7 / Node 3 with Root 7 / 7:12 — completely different concepts.',
  },
];

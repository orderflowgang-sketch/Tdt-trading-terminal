// ============================================================
// TDT Open Separators
// On the 15M chart, vertical separators at:
// 02:00, 06:00, 10:00, 14:00, 18:00, 22:00 SAST
// These are TDT open separators (not generic exchange separators).
// Must use actual candle timestamps.
// ============================================================

import { TDT_SEPARATOR_HOURS } from './nodeEngine';

export interface SeparatorInfo {
  hour: number;
  label: string;
  fullLabel: string;
}

/**
 * TDT Open Separator definitions
 */
export const TDT_OPEN_SEPARATORS: SeparatorInfo[] = TDT_SEPARATOR_HOURS.map((h) => ({
  hour: h,
  label: `${h.toString().padStart(2, '0')}:00`,
  fullLabel: `TDT OPEN ${h.toString().padStart(2, '0')}:00`,
}));

/**
 * Given a Unix timestamp, determine if it falls on a TDT separator hour
 * in the specified timezone.
 */
export function getSeparatorForTimestamp(
  timestamp: number,
  timezone: string = 'Africa/Johannesburg'
): SeparatorInfo | null {
  const date = new Date(timestamp);
  try {
    const hourStr = new Intl.DateTimeFormat('en-US', {
      timeZone: timezone,
      hour: 'numeric',
      hour12: false,
    }).format(date);
    const hour = parseInt(hourStr, 10);
    const sep = TDT_OPEN_SEPARATORS.find((s) => s.hour === hour);
    return sep ?? null;
  } catch {
    const utcHour = (date.getUTCHours() + 2) % 24; // approximate SAST
    return TDT_OPEN_SEPARATORS.find((s) => s.hour === utcHour) ?? null;
  }
}

/**
 * Get all separator timestamps within a range of candles.
 * Returns Unix timestamps that align to candle boundaries.
 */
export function getSeparatorTimestampsInRange(
  startTime: number,
  endTime: number,
  timezone: string = 'Africa/Johannesburg',
  intervalMs: number = 15 * 60 * 1000
): { timestamp: number; separator: SeparatorInfo }[] {
  const results: { timestamp: number; separator: SeparatorInfo }[] = [];

  // Walk through each candle interval and check if it falls on a separator hour
  for (let ts = startTime; ts <= endTime; ts += intervalMs) {
    const sep = getSeparatorForTimestamp(ts, timezone);
    if (sep) {
      // Only add if we haven't already added this separator (check for same hour)
      const last = results[results.length - 1];
      if (!last || last.separator.hour !== sep.hour || ts - last.timestamp > 60 * 60 * 1000) {
        results.push({ timestamp: ts, separator: sep });
      }
    }
  }

  return results;
}

/**
 * Other time separators (1H, 4H, Daily) — these are general time markers.
 */
export function getHourlySeparators(
  startTime: number,
  endTime: number,
  timezone: string = 'Africa/Johannesburg'
): number[] {
  const results: number[] = [];
  const hourMs = 60 * 60 * 1000;
  for (let ts = startTime; ts <= endTime; ts += hourMs) {
    const date = new Date(ts);
    try {
      const minStr = new Intl.DateTimeFormat('en-US', {
        timeZone: timezone,
        minute: 'numeric',
      }).format(date);
      if (parseInt(minStr, 10) === 0) {
        results.push(ts);
      }
    } catch {
      if (date.getUTCMinutes() === 0) results.push(ts);
    }
  }
  return results;
}

/**
 * Get 4H separator timestamps (every 4 hours on the hour).
 */
export function get4HSeparators(
  startTime: number,
  endTime: number,
  timezone: string = 'Africa/Johannesburg'
): number[] {
  const results: number[] = [];
  const fourHourMs = 4 * 60 * 60 * 1000;
  for (let ts = startTime; ts <= endTime; ts += 15 * 60 * 1000) {
    const sep = getSeparatorForTimestamp(ts, timezone);
    if (sep && [2, 6, 10, 14, 18, 22].includes(sep.hour)) {
      const last = results[results.length - 1];
      if (!last || ts - last >= fourHourMs) {
        results.push(ts);
      }
    }
  }
  return results;
}

/**
 * Get daily separator timestamps (at 02:00 SAST — the TDT day start).
 */
export function getDailySeparators(
  startTime: number,
  endTime: number,
  timezone: string = 'Africa/Johannesburg'
): number[] {
  const results: number[] = [];
  const dayMs = 24 * 60 * 60 * 1000;
  for (let ts = startTime; ts <= endTime; ts += 60 * 60 * 1000) {
    const sep = getSeparatorForTimestamp(ts, timezone);
    if (sep && sep.hour === 2) {
      const last = results[results.length - 1];
      if (!last || ts - last >= dayMs - 60 * 60 * 1000) {
        results.push(ts);
      }
    }
  }
  return results;
}

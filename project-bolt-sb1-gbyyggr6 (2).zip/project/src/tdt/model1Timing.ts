// ============================================================
// TDT Model 1 Calendar Timing
// Authoritative root-to-node mappings.
// These are CALENDAR-ROOT based Model 1 events (not date-based).
//
// With the 02:00 SAST anchored node mapping:
//   Node 6  = 07:00 SAST
//   Node 9  = 10:00 SAST
//   Node 12 = 13:00 SAST  (Mid-sequence transition)
//   Node 13 = 14:00 SAST
//   Node 17 = 18:00 SAST
//   Node 20 = 21:00 SAST  (Late-session liquidity expansion)
//
// Ratio 7:12 is displayed statically for Root 7 to prevent
// 7:undefined or NaN errors.
// ============================================================

import { Model1CalendarEvent } from '@/types';
import { getNodeLabel } from './nodeEngine';

/**
 * Authoritative Model 1 calendar mappings by root.
 * NEVER use: 1:7, 7:21, 9:27 — those are incorrect.
 *
 * The ratio "root:node" is authoritative and immutable.
 * The sastTime is derived from the node number via getNodeLabel().
 */
const ROOT_MAPPINGS: Record<number, Model1CalendarEvent> = {
  1: {
    root: 1,
    ratio: '1:6',
    node: 6,
    sastTime: getNodeLabel(6), // 07:00
    type: 'Model 1',
    label: 'Root 1 — Node 6 — 07:00 SAST',
  },
  3: {
    root: 3,
    ratio: '3:12',
    node: 12,
    sastTime: getNodeLabel(12), // 13:00
    type: 'Model 1',
    label: 'Root 3 — Node 12 — 13:00 SAST',
  },
  5: {
    root: 5,
    ratio: '5:17',
    node: 17,
    sastTime: getNodeLabel(17), // 18:00
    type: 'Model 1',
    label: 'Root 5 — Node 17 — 18:00 SAST',
  },
  7: {
    root: 7,
    ratio: '7:12',
    node: 12,
    sastTime: getNodeLabel(12), // 13:00
    type: 'Model 1',
    label: 'Root 7 — Node 12 — 13:00 SAST',
  },
  9: {
    root: 9,
    ratio: '9:9',
    node: 9,
    sastTime: getNodeLabel(9), // 10:00
    type: 'Early Expansion',
    label: 'Root 9 — Node 9 — 10:00 SAST (Early Expansion)',
  },
};

/**
 * Root 3 continuation event: 3:13, Node 13, 14:00 SAST
 * 3:13 is a 7-sum event (3 + 4 = 7, where node 13 → root+node = 3+13=16 → 1+6=7)
 */
const ROOT3_CONTINUATION: Model1CalendarEvent = {
  root: 3,
  ratio: '3:13',
  node: 13,
  sastTime: getNodeLabel(13), // 14:00
  type: 'Continuation',
  label: 'Root 3 Continuation — Node 13 — 14:00 SAST (7-Sum)',
};

/**
 * Get the primary Model 1 calendar event for a digital root.
 * Returns null for non-expansion roots (2, 4, 6, 8).
 */
export function getModel1Event(root: number): Model1CalendarEvent | null {
  return ROOT_MAPPINGS[root] ?? null;
}

/**
 * Get ALL Model 1 calendar events for a digital root (including continuations).
 */
export function getAllModel1Events(root: number): Model1CalendarEvent[] {
  const events: Model1CalendarEvent[] = [];
  const primary = getModel1Event(root);
  if (primary) events.push(primary);
  if (root === 3) {
    events.push(ROOT3_CONTINUATION);
  }
  return events;
}

/**
 * Check if a root has a Model 1 event.
 */
export function hasModel1Event(root: number): boolean {
  return root in ROOT_MAPPINGS;
}

/**
 * Get the continuation event for root 3.
 */
export function getRoot3Continuation(): Model1CalendarEvent {
  return ROOT3_CONTINUATION;
}

// ============================================================
// DATE-BASED Model 1 events (separate from calendar-root events)
// These are the user-defined date-specific Model 1 events.
// DO NOT confuse Date 7 / Node 3 with Root 7 / 7:12.
// ============================================================

export type DateModel1Event = {
  dateNumber: number; // day of month
  description: string;
  node: number;
  sastTime: string;
  eventType: string;
  directionRule: string;
};

/**
 * Date-based Model 1 events.
 * sastTime is derived from node via getNodeLabel().
 * Node 1 = 02:00 SAST (cycle anchor).
 */
export const DATE_MODEL1_EVENTS: Record<number, DateModel1Event> = {
  1: {
    dateNumber: 1,
    description: 'Node 6 close → Node 7 entry. Direction from confirmed 4H MSS.',
    node: 7,
    sastTime: getNodeLabel(7), // 08:00
    eventType: 'Node 6→7 Entry',
    directionRule: 'mss_direction',
  },
  3: {
    dateNumber: 3,
    description: '3:13 is a 7-sum event. Direction from confirmed 4H MSS.',
    node: 13,
    sastTime: getNodeLabel(13), // 14:00
    eventType: '7-Sum Event',
    directionRule: 'mss_direction',
  },
  4: {
    dateNumber: 4,
    description: '4:13 is a 7-sum sweep. Even day opposes HTF trend.',
    node: 13,
    sastTime: getNodeLabel(13), // 14:00
    eventType: '7-Sum Counter-Trend Sweep',
    directionRule: 'counter_trend',
  },
  5: {
    dateNumber: 5,
    description: '5:17 retracement peak after 4H MSS. Direction of that MSS.',
    node: 17,
    sastTime: getNodeLabel(17), // 18:00
    eventType: 'Retracement Peak',
    directionRule: 'mss_direction',
  },
  6: {
    dateNumber: 6,
    description: 'Continuation of Date 5. Preserve Date 5 directional context.',
    node: 17,
    sastTime: getNodeLabel(17), // 18:00
    eventType: 'Continuation',
    directionRule: 'preserve_date5',
  },
  7: {
    dateNumber: 7,
    description: 'Node 3 (04:00 SAST) — retest of 4H MSS. Trade retest in MSS direction.',
    node: 3,
    sastTime: getNodeLabel(3), // 04:00
    eventType: 'MSS Retest',
    directionRule: 'mss_direction',
  },
};

/**
 * Get the date-based Model 1 event for a specific day of month.
 */
export function getDateModel1Event(dayOfMonth: number): DateModel1Event | null {
  return DATE_MODEL1_EVENTS[dayOfMonth] ?? null;
}

/**
 * Check if a date has a date-based Model 1 event.
 */
export function hasDateModel1Event(dayOfMonth: number): boolean {
  return dayOfMonth in DATE_MODEL1_EVENTS;
}

// ============================================================
// TDT Central Calculation
// Combines digital root + node engine + Model 1 timing
// to produce complete TDT day information.
// ============================================================

import { TDTDayInfo, Model1CalendarEvent } from '@/types';
import { digitalRoot, isExpansionRoot, rootType } from './digitalRoot';
import { getTimezoneTime, getCurrentNode, getNodeLabel, nodeToHour, hourToNode } from './nodeEngine';
import { getModel1Event, getAllModel1Events, getDateModel1Event, hasDateModel1Event, DateModel1Event } from './model1Timing';

/**
 * Calculate full TDT info for a given date in the selected timezone.
 */
export function calculateTDTDay(date: Date, timezone: string = 'Africa/Johannesburg'): TDTDayInfo {
  const tzTime = getTimezoneTime(date, timezone);
  const dayOfMonth = tzTime.day;
  const root = digitalRoot(dayOfMonth);
  const expansion = isExpansionRoot(root);
  const model1Event = getModel1Event(root);

  // Determine status string
  let status: string;
  if (expansion) {
    status = 'EXPANSION DAY';
  } else {
    status = 'NON-EXPANSION';
  }

  // Build the ratio string
  const ratio = model1Event ? model1Event.ratio : null;

  return {
    date: new Date(date),
    dayOfMonth,
    digitalRoot: root,
    isExpansion: expansion,
    rootType: rootType(root),
    model1Event,
    ratio,
    status,
  };
}

/**
 * Get all Model 1 events for a date (both calendar-root and date-based).
 */
export function getAllEventsForDate(date: Date, timezone: string = 'Africa/Johannesburg'): {
  calendarEvents: Model1CalendarEvent[];
  dateEvent: ReturnType<typeof getDateModel1Event>;
} {
  const info = calculateTDTDay(date, timezone);
  const calendarEvents = getAllModel1Events(info.digitalRoot);
  const dateEvent = getDateModel1Event(info.dayOfMonth);
  return { calendarEvents, dateEvent };
}

/**
 * Build a concrete Date object for a given calendar day + node number,
 * representing the exact SAST timestamp when that node starts.
 */
function buildEventTimestamp(
  year: number,
  month: number, // 0-11
  day: number,
  node: number,
  timezone: string
): Date {
  const hour = nodeToHour(node);
  // Construct a date at the given SAST time. Since we can't directly create
  // a Date in a specific timezone, we use the offset for Africa/Johannesburg (UTC+2).
  // For most timezones we can compute the offset, but SAST is always UTC+2 (no DST).
  const utcHour = (hour - 2 + 24) % 24;
  return new Date(Date.UTC(year, month, day, utcHour, 0, 0));
}

/**
 * Get the next upcoming TDT event from the current time.
 *
 * This compares each candidate event's SAST timestamp against the current
 * system time. If an event's time has already passed today, it rolls over
 * to the next day that has an event. This ensures we always show the NEXT
 * upcoming event, not one that already happened.
 */
export function getNextTDTEvent(fromDate: Date, timezone: string = 'Africa/Johannesburg'): {
  date: Date;
  event: Model1CalendarEvent | NonNullable<DateModel1Event>;
  isDateBased: boolean;
  eventTimestamp: Date;
} | null {
  const tzNow = getTimezoneTime(fromDate, timezone);
  const currentMinutes = tzNow.hour * 60 + tzNow.minute;

  // Collect all candidate events for today, sorted by node hour
  interface Candidate {
    date: Date;
    event: Model1CalendarEvent | NonNullable<DateModel1Event>;
    isDateBased: boolean;
    eventMinutes: number; // minutes from midnight SAST
    eventTimestamp: Date;
  }

  for (let dayOffset = 0; dayOffset <= 30; dayOffset++) {
    const checkDate = new Date(fromDate);
    checkDate.setDate(checkDate.getDate() + dayOffset);
    const tzDate = getTimezoneTime(checkDate, timezone);
    const info = calculateTDTDay(checkDate, timezone);

    const candidates: Candidate[] = [];

    // Calendar-root events
    const calEvents = getAllModel1Events(info.digitalRoot);
    for (const evt of calEvents) {
      const eventHour = nodeToHour(evt.node);
      const eventMinutes = eventHour * 60;
      const eventTimestamp = buildEventTimestamp(tzDate.year, tzDate.month, tzDate.day, evt.node, timezone);
      candidates.push({
        date: checkDate,
        event: evt,
        isDateBased: false,
        eventMinutes,
        eventTimestamp,
      });
    }

    // Date-based events
    const dateEvt = getDateModel1Event(info.dayOfMonth);
    if (dateEvt) {
      const eventHour = nodeToHour(dateEvt.node);
      const eventMinutes = eventHour * 60;
      const eventTimestamp = buildEventTimestamp(tzDate.year, tzDate.month, tzDate.day, dateEvt.node, timezone);
      candidates.push({
        date: checkDate,
        event: dateEvt,
        isDateBased: true,
        eventMinutes,
        eventTimestamp,
      });
    }

    // Sort by event time ascending
    candidates.sort((a, b) => a.eventMinutes - b.eventMinutes);

    // On the current day (dayOffset === 0), skip events that already passed
    if (dayOffset === 0) {
      for (const c of candidates) {
        if (c.eventMinutes > currentMinutes) {
          return {
            date: c.date,
            event: c.event,
            isDateBased: c.isDateBased,
            eventTimestamp: c.eventTimestamp,
          };
        }
      }
      // All of today's events have passed — continue to next day
      continue;
    }

    // Future days — return the first event
    if (candidates.length > 0) {
      const first = candidates[0];
      return {
        date: first.date,
        event: first.event,
        isDateBased: first.isDateBased,
        eventTimestamp: first.eventTimestamp,
      };
    }
  }

  return null;
}

/**
 * Get TDT info for a specific day-of-month in a given month.
 */
export function getTDTForDay(year: number, month: number, day: number, timezone: string = 'Africa/Johannesburg'): TDTDayInfo {
  // Build a date at approximately noon to avoid TZ edge issues
  const date = new Date(Date.UTC(year, month, day, 10, 0, 0));
  return calculateTDTDay(date, timezone);
}

/**
 * Get current TDT status including current node.
 */
export function getCurrentTDTStatus(date: Date, timezone: string = 'Africa/Johannesburg') {
  const info = calculateTDTDay(date, timezone);
  const node = getCurrentNode(date, timezone);
  const nodeLabel = getNodeLabel(node);
  const tzTime = getTimezoneTime(date, timezone);
  const currentTimeStr = `${tzTime.hour.toString().padStart(2, '0')}:${tzTime.minute.toString().padStart(2, '0')}`;

  return {
    ...info,
    currentNode: node,
    currentNodeLabel: nodeLabel,
    currentTimeStr,
  };
}

/**
 * Re-export for convenience
 */
export { digitalRoot, isExpansionRoot, hasDateModel1Event };

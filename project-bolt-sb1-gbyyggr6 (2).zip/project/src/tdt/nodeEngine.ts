// ============================================================
// TDT Node Engine — 02:00 SAST Anchored Cycle
// The 24-hour cycle is anchored at 02:00 SAST as Node 1.
//
// Strict Node Mapping:
//   Node 1  = 02:00 SAST  (Cycle Start / Anchor)
//   Node 2  = 03:00 SAST
//   ...
//   Node 11 = 12:00 SAST
//   Node 12 = 13:00 SAST  (Mid-sequence transition)
//   ...
//   Node 20 = 21:00 SAST  (Late-session liquidity expansion)
//   ...
//   Node 23 = 00:00 SAST  (midnight)
//   Node 24 = 01:00 SAST  (cycle wrap)
//
// Formula: node = ((sastHour - 2 + 24) % 24) + 1
//   sastHour 2  → node 1
//   sastHour 13 → node 12
//   sastHour 21 → node 20
//   sastHour 0  → node 23
//   sastHour 1  → node 24
// ============================================================

import { TDTNode } from '@/types';

const CYCLE_ANCHOR_HOUR = 2; // 02:00 SAST

/**
 * All 24 TDT nodes with their SAST hour mappings.
 * Node 1 = 02:00 SAST, Node 12 = 13:00 SAST, Node 20 = 21:00 SAST, etc.
 */
export const TDT_NODES: TDTNode[] = Array.from({ length: 24 }, (_, i) => {
  const node = i + 1;
  const sastHour = (CYCLE_ANCHOR_HOUR + i) % 24;
  const hourStr = sastHour.toString().padStart(2, '0');
  return {
    node,
    sastHour,
    label: `${hourStr}:00`,
    isSeparator: [2, 6, 10, 14, 18, 22].includes(sastHour),
  };
});

/**
 * TDT Open Separator hours (SAST): 02:00, 06:00, 10:00, 14:00, 18:00, 22:00
 */
export const TDT_SEPARATOR_HOURS = [2, 6, 10, 14, 18, 22];

/**
 * Key anchor nodes.
 */
export const NODE_1_HOUR = 2;     // 02:00 SAST
export const NODE_12_HOUR = 13;   // 13:00 SAST
export const NODE_20_HOUR = 21;   // 21:00 SAST

/**
 * Calculate the current TDT node from a date in the selected timezone.
 * Anchored at 02:00 SAST = Node 1.
 */
export function getCurrentNode(date: Date, timezone: string = 'Africa/Johannesburg'): number {
  const sastHour = getHourInTimezone(date, timezone);
  return ((sastHour - CYCLE_ANCHOR_HOUR + 24) % 24) + 1;
}

/**
 * Get the SAST hour (0-23) for a given date in the selected timezone.
 */
export function getHourInTimezone(date: Date, timezone: string): number {
  try {
    const formatted = new Intl.DateTimeFormat('en-US', {
      timeZone: timezone,
      hour: 'numeric',
      hour12: false,
    }).format(date);
    return parseInt(formatted, 10);
  } catch {
    return (date.getUTCHours() + 2) % 24;
  }
}

/**
 * Get full date/time info in the selected timezone
 */
export function getTimezoneTime(date: Date, timezone: string): {
  year: number;
  month: number; // 0-11
  day: number;
  hour: number;
  minute: number;
  weekday: number;
} {
  try {
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone: timezone,
      year: 'numeric',
      month: 'numeric',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
      hour12: false,
      weekday: 'short',
    }).formatToParts(date);

    const map: Record<string, number> = {};
    for (const p of parts) {
      if (p.type !== 'weekday' && p.type !== 'literal') {
        map[p.type] = parseInt(p.value, 10);
      }
    }

    const weekdayMap: Record<string, number> = {
      Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6,
    };
    const wdPart = parts.find((p) => p.type === 'weekday');

    return {
      year: map.year,
      month: map.month - 1,
      day: map.day,
      hour: map.hour === 24 ? 0 : map.hour,
      minute: map.minute,
      weekday: wdPart ? weekdayMap[wdPart.value] ?? 0 : 0,
    };
  } catch {
    const utc = date.getUTCHours() + 2;
    return {
      year: date.getUTCFullYear(),
      month: date.getUTCMonth(),
      day: date.getUTCDate(),
      hour: utc % 24,
      minute: date.getUTCMinutes(),
      weekday: date.getUTCDay(),
    };
  }
}

/**
 * Get the calendar day-of-month in the selected timezone.
 */
export function getDayInTimezone(date: Date, timezone: string): number {
  return getTimezoneTime(date, timezone).day;
}

/**
 * Get the label for a node number (1-24).
 * Node 1 = 02:00, Node 12 = 13:00, Node 20 = 21:00, etc.
 */
export function getNodeLabel(node: number): string {
  if (node < 1 || node > 24) return '--:--';
  return TDT_NODES[node - 1].label;
}

/**
 * Get the SAST hour for a node number (1-24).
 * Node 1 → 02:00 (hour 2), Node 12 → 13:00 (hour 13), etc.
 */
export function getNodeSastHour(node: number): number {
  if (node < 1 || node > 24) return -1;
  return TDT_NODES[node - 1].sastHour;
}

/**
 * Format SAST time string from hour
 */
export function formatSastHour(hour: number): string {
  return `${hour.toString().padStart(2, '0')}:00`;
}

/**
 * Convert a node number to its SAST hour.
 * Node 1 → hour 2, Node 12 → hour 13, Node 24 → hour 1.
 */
export function nodeToHour(node: number): number {
  if (node < 1 || node > 24) return -1;
  return TDT_NODES[node - 1].sastHour;
}

/**
 * Convert a SAST hour to its node number.
 * Hour 2 → Node 1, Hour 13 → Node 12, Hour 1 → Node 24.
 */
export function hourToNode(hour: number): number {
  return ((hour - CYCLE_ANCHOR_HOUR + 24) % 24) + 1;
}

// ============================================================
// TDT Digital Root Engine
// Calculates the digital root of a calendar day number.
// Continues reducing until a single digit 1-9 remains.
// ============================================================

/**
 * Calculate the digital root of a number.
 * 1 -> 1, 5 -> 5, 9 -> 9, 10 -> 1, 14 -> 5, 18 -> 9, 23 -> 5, 27 -> 9, 29 -> 2
 */
export function digitalRoot(n: number): number {
  if (n <= 0) return 0;
  let val = n;
  while (val >= 10) {
    val = String(val)
      .split('')
      .reduce((sum, d) => sum + parseInt(d, 10), 0);
  }
  return val;
}

/**
 * Expansion roots: 1, 3, 5, 7, 9
 * Non-expansion roots: 2, 4, 6, 8
 * Classification is based ONLY on the calendar date, never market data.
 */
export function isExpansionRoot(root: number): boolean {
  return root === 1 || root === 3 || root === 5 || root === 7 || root === 9;
}

/**
 * Get root type string
 */
export function rootType(root: number): 'expansion' | 'non-expansion' {
  return isExpansionRoot(root) ? 'expansion' : 'non-expansion';
}

/**
 * 7-Sum hypothesis check.
 * The user observes recurring TDT timing where components sum to 7.
 * e.g. 3+4, 4+3, 1+6, 6+1
 * This is an EMPIRICAL HYPOTHESIS, not scientifically proven.
 * It does NOT automatically create a trade.
 */
export function isSevenSum(a: number, b: number): boolean {
  return a + b === 7;
}

/**
 * Get all 7-sum pairs for a given day number.
 * Returns pairs (dayPart, nodePart) where dayPart + nodePart = 7.
 */
export function getSevenSumPairs(dayOfMonth: number): [number, number][] {
  const pairs: [number, number][] = [];
  const root = digitalRoot(dayOfMonth);
  // Check if the root has a 7-sum relationship
  for (let i = 1; i <= 6; i++) {
    if (i + (7 - i) === 7) {
      pairs.push([i, 7 - i]);
    }
  }
  return pairs;
}

/**
 * Check if a specific date:node ratio is a 7-sum event
 */
export function isSevenSumRatio(root: number, node: number): boolean {
  return root + node === 7;
}

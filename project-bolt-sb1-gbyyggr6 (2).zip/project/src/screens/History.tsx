import { useState, useMemo, useRef, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Clock, TrendingUp, TrendingDown } from 'lucide-react';
import { AppSettings, SignalResult } from '@/types';
import { useHistoricalData } from '@/hooks/useMarketData';
import { generateHistoricalSignal } from '@/signals/model1';
import { calculateTDTDay } from '@/tdt';
import { detect4HRaids } from '@/structure/htfRaid';
import { detectMSSFromRaid } from '@/structure/mss';
import { ChartRenderer, ChartOverlays } from '@/chart/mainChart';
import { renderHTFPanel, HTFData } from '@/chart/floatingHTF';
import { TIMEFRAMES } from '@/types';

export default function HistoryScreen({ settings }: { settings: AppSettings }) {
  const [selectedDate, setSelectedDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 1);
    return d;
  });
  const [instrument, setInstrument] = useState(settings.instrument);

  const { loading, error, candles15m, candles4h, candles1d, candles1w } = useHistoricalData(
    instrument, selectedDate, settings.timezone
  );

  const tdtInfo = useMemo(() => calculateTDTDay(selectedDate, settings.timezone), [selectedDate, settings.timezone]);

  const signal: SignalResult | null = useMemo(() => {
    if (candles15m.length === 0 || candles4h.length === 0) return null;
    try {
      return generateHistoricalSignal(selectedDate, candles15m, candles4h, settings.timezone);
    } catch {
      return null;
    }
  }, [selectedDate, candles15m, candles4h, settings.timezone]);

  const raids = useMemo(() => detect4HRaids(candles4h, settings.timezone), [candles4h, settings.timezone]);
  const relevantRaid = useMemo(() => {
    const targetDay = tdtInfo.dayOfMonth;
    for (let i = raids.length - 1; i >= 0; i--) {
      const raidDay = parseInt(new Intl.DateTimeFormat('en-US', { timeZone: settings.timezone, day: 'numeric' }).format(new Date(raids[i].raidTimestamp)), 10);
      if (raidDay === targetDay) return raids[i];
    }
    return null;
  }, [raids, tdtInfo.dayOfMonth, settings.timezone]);

  const mss = useMemo(() => {
    if (!relevantRaid) return null;
    return detectMSSFromRaid(candles15m, relevantRaid);
  }, [relevantRaid, candles15m]);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const htfCanvasRef = useRef<HTMLCanvasElement>(null);
  const rendererRef = useRef<ChartRenderer | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Render historical chart
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container || candles15m.length === 0) return;

    const rect = container.getBoundingClientRect();
    const htfWidth = settings.htfVisibility ? settings.htfPanelWidth : 0;
    const chartWidth = rect.width - htfWidth;
    const chartHeight = rect.height;

    canvas.width = chartWidth;
    canvas.height = chartHeight;

    if (!rendererRef.current) {
      rendererRef.current = new ChartRenderer(canvas);
    }
    rendererRef.current.setCandles(candles15m);

    const overlays: ChartOverlays = {
      raids: relevantRaid ? [relevantRaid] : [],
      mssEvents: mss ? [mss] : [],
      signal,
      tdtSeparators: true,
      tdtNodes: true,
    };

    rendererRef.current.setConfig({
      width: chartWidth,
      height: chartHeight,
      settings,
      timezone: settings.timezone,
      overlays,
    });

    rendererRef.current.render();
  }, [candles15m, relevantRaid, mss, signal, settings]);

  // Render HTF
  useEffect(() => {
    const htfCanvas = htfCanvasRef.current;
    if (!htfCanvas || !settings.htfVisibility) return;

    const height = htfCanvas.parentElement?.clientHeight ?? 300;
    htfCanvas.width = settings.htfPanelWidth;
    htfCanvas.height = height;

    const ctx = htfCanvas.getContext('2d');
    if (!ctx) return;

    const htfData: HTFData = {
      fourH: candles4h,
      oneDay: candles1d,
      oneWeek: candles1w,
    };

    renderHTFPanel(ctx, 0, 0, settings.htfPanelWidth, height, htfData, settings);
  }, [candles4h, candles1d, candles1w, settings]);

  const changeDate = (delta: number) => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() + delta);
    setSelectedDate(d);
  };

  const signalColor =
    signal?.state === 'BUY' ? 'text-[#26a69a] bg-[#26a69a]/10 border-[#26a69a]/30' :
    signal?.state === 'SELL' ? 'text-[#ef5350] bg-[#ef5350]/10 border-[#ef5350]/30' :
    signal?.state === 'WAITING_FOR_CONFIRMATION' ? 'text-[#f59e0b] bg-[#f59e0b]/10 border-[#f59e0b]/30' :
    'text-gray-500 bg-gray-500/10 border-gray-500/30';

  return (
    <div className="p-3 space-y-3 h-full flex flex-col">
      <div className="text-[10px] text-gray-500 tracking-widest">HISTORY</div>

      {/* Controls */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="flex items-center gap-1">
          <button onClick={() => changeDate(-1)} className="p-1.5 rounded hover:bg-[#1a1f2e] text-gray-400">
            <ChevronLeft size={16} />
          </button>
          <input
            type="date"
            value={selectedDate.toISOString().slice(0, 10)}
            onChange={(e) => setSelectedDate(new Date(e.target.value + 'T12:00:00'))}
            className="bg-[#0d1117] border border-[#1a1f2e] text-gray-200 text-xs rounded px-2 py-1 focus:outline-none focus:border-[#26a69a]"
          />
          <button onClick={() => changeDate(1)} className="p-1.5 rounded hover:bg-[#1a1f2e] text-gray-400">
            <ChevronRight size={16} />
          </button>
        </div>

        <select
          value={instrument}
          onChange={(e) => setInstrument(e.target.value)}
          className="bg-[#0d1117] border border-[#1a1f2e] text-gray-200 text-xs rounded px-2 py-1 focus:outline-none focus:border-[#26a69a]"
        >
          {['BTC/USD', 'ETH/USD', 'SOL/USD', 'BNB/USD', 'XRP/USD', 'XAU/USD'].map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
      </div>

      {/* TDT info for selected date */}
      <div className="grid grid-cols-3 gap-2">
        <div className="rounded-lg border border-[#1a1f2e] bg-[#0d1117] p-2">
          <div className="text-[9px] text-gray-500 tracking-widest">ROOT</div>
          <div className={`text-sm font-bold ${tdtInfo.isExpansion ? 'text-[#f59e0b]' : 'text-gray-300'}`}>
            {tdtInfo.digitalRoot}
          </div>
        </div>
        <div className="rounded-lg border border-[#1a1f2e] bg-[#0d1117] p-2">
          <div className="text-[9px] text-gray-500 tracking-widest">STATUS</div>
          <div className={`text-sm font-bold ${tdtInfo.isExpansion ? 'text-[#f59e0b]' : 'text-gray-300'}`}>
            {tdtInfo.isExpansion ? 'EXPANSION' : 'NON-EXP'}
          </div>
        </div>
        <div className="rounded-lg border border-[#1a1f2e] bg-[#0d1117] p-2">
          <div className="text-[9px] text-gray-500 tracking-widest">RATIO</div>
          <div className="text-sm font-bold text-gray-300">{tdtInfo.ratio ?? '—'}</div>
        </div>
      </div>

      {/* Signal */}
      <div className={`rounded-lg border p-3 ${signalColor}`}>
        <div className="flex items-center gap-2">
          {signal?.state === 'BUY' ? <TrendingUp size={20} /> :
           signal?.state === 'SELL' ? <TrendingDown size={20} /> :
           <Clock size={20} />}
          <div className="text-lg font-black tracking-wide">
            {signal?.state === 'WAITING_FOR_CONFIRMATION' ? 'WAITING FOR CONFIRMATION' :
             signal?.state ?? 'NO SIGNAL'}
          </div>
        </div>
        {signal?.explanation && (
          <div className="text-[11px] mt-2 opacity-80 leading-relaxed">{signal.explanation}</div>
        )}
      </div>

      {/* Error */}
      {error && (
        <div className="rounded-lg border border-[#ef5350]/30 bg-[#ef5350]/10 p-3 text-xs text-[#ef5350]">
          MARKET DATA UNAVAILABLE: {error}
        </div>
      )}

      {/* Historical chart */}
      <div className="flex-1 flex gap-1 min-h-[250px]">
        <div ref={containerRef} className="flex-1 relative bg-[#0a0e14] rounded-lg overflow-hidden border border-[#1a1f2e]">
          {loading && (
            <div className="absolute inset-0 flex items-center justify-center z-10 bg-[#0a0e14]/80">
              <div className="text-xs text-gray-500 animate-pulse">LOADING HISTORICAL DATA...</div>
            </div>
          )}
          {!loading && candles15m.length === 0 && !error && (
            <div className="absolute inset-0 flex items-center justify-center z-10">
              <div className="text-xs text-gray-600">NO DATA FOR SELECTED DATE</div>
            </div>
          )}
          <canvas ref={canvasRef} className="block touch-none" />
        </div>
        {settings.htfVisibility && (
          <div className="flex-shrink-0 bg-[#0d1117] rounded-lg overflow-hidden border border-[#1a1f2e]" style={{ width: settings.htfPanelWidth }}>
            <canvas ref={htfCanvasRef} className="block" />
          </div>
        )}
      </div>

      {/* Raid & MSS details */}
      {relevantRaid && (
        <div className="rounded-lg border border-[#1a1f2e] bg-[#0d1117] p-3 space-y-2">
          <div className="text-[10px] text-gray-500 tracking-widest">4H RAID ANALYSIS</div>
          <div className="flex justify-between text-xs">
            <span className="text-gray-500">Direction</span>
            <span className={`font-bold ${relevantRaid.raidDirection === 'long' ? 'text-[#26a69a]' : 'text-[#ef5350]'}`}>
              {relevantRaid.raidDirection === 'long' ? 'LONG (low raided)' : 'SHORT (high raided)'}
            </span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-gray-500">Turtle Soup</span>
            <span className={`font-bold ${relevantRaid.turtleSoup ? 'text-[#f59e0b]' : 'text-gray-400'}`}>
              {relevantRaid.turtleSoup ? 'YES' : 'NO'}
            </span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-gray-500">Raid Price</span>
            <span className="font-bold text-gray-200">{relevantRaid.raidPrice}</span>
          </div>
          {mss && (
            <>
              <div className="border-t border-[#1a1f2e] pt-2 mt-2">
                <div className="text-[10px] text-gray-500 tracking-widest mb-1">15M MSS</div>
                <div className="flex justify-between text-xs">
                  <span className="text-gray-500">Direction</span>
                  <span className={`font-bold ${mss.direction === 'bullish' ? 'text-[#26a69a]' : 'text-[#ef5350]'}`}>
                    {mss.direction.toUpperCase()}
                  </span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-gray-500">Break Level</span>
                  <span className="font-bold text-gray-200">{mss.breakLevel}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-gray-500">Confirmation Price</span>
                  <span className="font-bold text-gray-200">{mss.confirmationPrice}</span>
                </div>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}

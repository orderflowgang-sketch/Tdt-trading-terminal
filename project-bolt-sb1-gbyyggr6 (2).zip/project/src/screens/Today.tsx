import { useState, useEffect, useMemo } from 'react';
import { TrendingUp, TrendingDown, Clock, Activity, Zap, AlertCircle } from 'lucide-react';
import { AppSettings, SignalResult } from '@/types';
import { getCurrentTDTStatus, getNextTDTEvent } from '@/tdt';
import { useMarketData } from '@/hooks/useMarketData';
import { generateLiveSignal } from '@/signals/model1';
import { detect4HRaids } from '@/structure/htfRaid';
import { detectSweeps, detectFVGs, detectOrderBlocks } from '@/structure/sweeps';

export default function TodayScreen({ settings }: { settings: AppSettings }) {
  const [now, setNow] = useState(new Date());
  const { loading, error, candles15m, candles4h, lastUpdate } = useMarketData(settings.instrument, settings.timeframe);

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const tdtStatus = useMemo(() => getCurrentTDTStatus(now, settings.timezone), [now, settings.timezone]);
  const nextEvent = useMemo(() => getNextTDTEvent(now, settings.timezone), [now, settings.timezone]);

  const signal: SignalResult | null = useMemo(() => {
    if (candles15m.length === 0 || candles4h.length === 0) return null;
    try {
      return generateLiveSignal(candles15m, candles4h, settings.timezone);
    } catch {
      return null;
    }
  }, [candles15m, candles4h, settings.timezone]);

  const raids = useMemo(() => detect4HRaids(candles4h, settings.timezone), [candles4h, settings.timezone]);
  const lastRaid = raids[raids.length - 1];

  // Sync turtle soup flag: if the signal engine classifies the raid as TURTLE SOUP,
  // the last raid card must reflect that.
  const turtleSoupSynced =
    (signal?.fourHRaid === 'TURTLE SOUP') || (lastRaid?.turtleSoup ?? false);

  const signalColor =
    signal?.state === 'BUY' ? 'text-[#26a69a] bg-[#26a69a]/10 border-[#26a69a]/30' :
    signal?.state === 'SELL' ? 'text-[#ef5350] bg-[#ef5350]/10 border-[#ef5350]/30' :
    signal?.state === 'WAITING_FOR_CONFIRMATION' ? 'text-[#f59e0b] bg-[#f59e0b]/10 border-[#f59e0b]/30' :
    'text-gray-500 bg-gray-500/10 border-gray-500/30';

  const signalIcon =
    signal?.state === 'BUY' ? <TrendingUp size={28} /> :
    signal?.state === 'SELL' ? <TrendingDown size={28} /> :
    signal?.state === 'WAITING_FOR_CONFIRMATION' ? <Clock size={28} /> :
    <AlertCircle size={28} />;

  return (
    <div className="p-3 space-y-3">
      {/* Title */}
      <div className="flex items-center justify-between">
        <div>
          <div className="text-[10px] text-gray-500 tracking-widest">TODAY</div>
          <div className="text-lg font-bold text-gray-200">
            {tdtStatus.dayOfMonth} {now.toLocaleString('en-US', { month: 'short', year: 'numeric' })}
          </div>
        </div>
        <div className="text-right">
          <div className="text-[10px] text-gray-500">SAST</div>
          <div className="text-sm font-bold text-[#26a69a] tabular-nums">{tdtStatus.currentTimeStr}</div>
        </div>
      </div>

      {/* TDT Status Cards */}
      <div className="grid grid-cols-2 gap-2">
        <StatusCard label="DATE ROOT" value={tdtStatus.digitalRoot.toString()} highlight={tdtStatus.isExpansion} />
        <StatusCard label="TDT STATUS" value={tdtStatus.status} highlight={tdtStatus.isExpansion} />
        <StatusCard label="CURRENT NODE" value={`Node ${tdtStatus.currentNode}`} subValue={tdtStatus.currentNodeLabel} />
        <StatusCard label="RATIO" value={tdtStatus.ratio ?? '—'} subValue={tdtStatus.model1Event?.type ?? ''} />
      </div>

      {/* Signal Card */}
      <div className={`rounded-lg border p-4 ${signalColor}`}>
        <div className="flex items-center gap-3">
          {signalIcon}
          <div className="flex-1">
            <div className="text-xs text-gray-400 tracking-widest mb-1">SIGNAL</div>
            <div className="text-2xl font-black tracking-wide">
              {signal?.state === 'WAITING_FOR_CONFIRMATION' ? 'WAITING' : signal?.state.replace(/_/g, ' ') ?? 'NO SIGNAL'}
            </div>
          </div>
          {loading && (
            <div className="text-xs text-gray-500 animate-pulse">LOADING...</div>
          )}
        </div>
      </div>

      {/* Error state */}
      {error && (
        <div className="rounded-lg border border-[#ef5350]/30 bg-[#ef5350]/10 p-3 text-xs text-[#ef5350]">
          <div className="flex items-center gap-2 mb-1">
            <AlertCircle size={14} />
            <span className="font-bold">MARKET DATA UNAVAILABLE</span>
          </div>
          <div className="text-[#ef5350]/70">{error}</div>
        </div>
      )}

      {/* Signal Details */}
      {signal && signal.state !== 'NO_SIGNAL' && (
        <div className="rounded-lg border border-[#1a1f2e] bg-[#0d1117] p-3 space-y-2">
          <div className="text-xs text-gray-500 tracking-widest mb-2">SIGNAL INFORMATION</div>
          <SignalRow label="Date" value={`${tdtStatus.dayOfMonth} ${now.toLocaleString('en-US', { month: 'short' })}`} />
          <SignalRow label="Root" value={signal.root.toString()} />
          <SignalRow label="TDT Ratio" value={signal.ratio ?? '—'} />
          <SignalRow label="TDT Node" value={signal.node ? `Node ${signal.node}` : '—'} />
          <SignalRow label="TDT Event Time" value={signal.eventTime ?? '—'} />
          <SignalRow label="HTF Bias" value={signal.htfBias.toUpperCase()} color={
            signal.htfBias === 'bullish' ? 'text-[#26a69a]' : signal.htfBias === 'bearish' ? 'text-[#ef5350]' : 'text-gray-400'
          } />
          <SignalRow label="4H Raid" value={signal.fourHRaid} color={
            signal.fourHRaid === 'CONFIRMED' ? 'text-[#26a69a]' :
            signal.fourHRaid === 'TURTLE SOUP' ? 'text-[#f59e0b]' : 'text-gray-400'
          } />
          <SignalRow label="15M MSS" value={signal.fifteenMSss.toUpperCase()} color={
            signal.fifteenMSss === 'bullish' ? 'text-[#26a69a]' : signal.fifteenMSss === 'bearish' ? 'text-[#ef5350]' : 'text-gray-400'
          } />
          {signal.triggerTime && (
            <SignalRow label="Trigger Time" value={new Date(signal.triggerTime).toLocaleString('en-US', {
              timeZone: settings.timezone, hour: '2-digit', minute: '2-digit', day: '2-digit', month: 'short',
            })} />
          )}
          {signal.triggerPrice && (
            <SignalRow label="Trigger Price" value={signal.triggerPrice.toString()} highlight />
          )}
          {signal.explanation && (
            <div className="pt-2 border-t border-[#1a1f2e] text-[11px] text-gray-500 leading-relaxed">
              {signal.explanation}
            </div>
          )}
        </div>
      )}

      {/* Next TDT Event */}
      {nextEvent && (
        <div className="rounded-lg border border-[#1a1f2e] bg-[#0d1117] p-3">
          <div className="flex items-center gap-2 mb-2">
            <Zap size={14} className="text-[#f59e0b]" />
            <div className="text-xs text-gray-500 tracking-widest">NEXT TDT EVENT</div>
          </div>
          <div className="text-sm text-gray-300">
            {nextEvent.date.toLocaleDateString('en-US', { day: 'numeric', month: 'short' })} — {'label' in nextEvent.event ? nextEvent.event.label : `${nextEvent.event.node}:00`}
          </div>
          {nextEvent.isDateBased && 'description' in nextEvent.event && (
            <div className="text-[11px] text-gray-500 mt-1">{nextEvent.event.description}</div>
          )}
          {nextEvent.eventTimestamp && (
            <div className="text-[11px] text-[#f59e0b] mt-1.5 tabular-nums">
              {(() => {
                const diff = nextEvent.eventTimestamp.getTime() - now.getTime();
                if (diff <= 0) return 'EVENT ACTIVE';
                const h = Math.floor(diff / 3600000);
                const m = Math.floor((diff % 3600000) / 60000);
                const s = Math.floor((diff % 60000) / 1000);
                return `In ${h}h ${m}m ${s}s`;
              })()}
            </div>
          )}
        </div>
      )}

      {/* 4H Raid info */}
      {lastRaid && (
        <div className="rounded-lg border border-[#1a1f2e] bg-[#0d1117] p-3">
          <div className="flex items-center gap-2 mb-2">
            <Activity size={14} className={lastRaid.raidDirection === 'long' ? 'text-[#26a69a]' : 'text-[#ef5350]'} />
            <div className="text-xs text-gray-500 tracking-widest">LAST 4H RAID</div>
          </div>
          <SignalRow label="Direction" value={lastRaid.raidDirection === 'long' ? 'LONG RAID (low raided)' : 'SHORT RAID (high raided)'} />
          <SignalRow label="Turtle Soup" value={turtleSoupSynced ? 'YES — closed back inside' : 'NO'} color={turtleSoupSynced ? 'text-[#f59e0b]' : undefined} />
          <SignalRow label="Raid Price" value={lastRaid.raidPrice.toString()} />
          <SignalRow label="Raid Time" value={new Date(lastRaid.raidTimestamp).toLocaleString('en-US', {
            timeZone: settings.timezone, hour: '2-digit', minute: '2-digit', day: '2-digit', month: 'short',
          })} />
        </div>
      )}

      {lastUpdate && (
        <div className="text-[10px] text-gray-600 text-center">
          Last update: {new Date(lastUpdate).toLocaleTimeString()}
        </div>
      )}
    </div>
  );
}

function StatusCard({ label, value, subValue, highlight }: {
  label: string; value: string; subValue?: string; highlight?: boolean;
}) {
  return (
    <div className={`rounded-lg border p-2.5 ${highlight ? 'border-[#f59e0b]/30 bg-[#f59e0b]/5' : 'border-[#1a1f2e] bg-[#0d1117]'}`}>
      <div className="text-[9px] text-gray-500 tracking-widest mb-1">{label}</div>
      <div className={`text-sm font-bold ${highlight ? 'text-[#f59e0b]' : 'text-gray-200'}`}>{value}</div>
      {subValue && <div className="text-[10px] text-gray-500 mt-0.5">{subValue}</div>}
    </div>
  );
}

function SignalRow({ label, value, color, highlight }: {
  label: string; value: string; color?: string; highlight?: boolean;
}) {
  return (
    <div className="flex justify-between items-center text-xs">
      <span className="text-gray-500">{label}</span>
      <span className={`font-bold ${color ?? (highlight ? 'text-[#26a69a]' : 'text-gray-200')}`}>{value}</span>
    </div>
  );
}

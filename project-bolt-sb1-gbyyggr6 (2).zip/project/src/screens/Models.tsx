import { useState } from 'react';
import { BookOpen, ChevronRight } from 'lucide-react';
import { AppSettings } from '@/types';
import { ROOT_MAPPINGS_LIST, DATE_EVENTS_LIST } from '@/data/modelReference';

export default function ModelsScreen({ settings }: { settings: AppSettings }) {
  const [expanded, setExpanded] = useState<string | null>(null);

  return (
    <div className="p-3 space-y-3">
      <div className="flex items-center gap-2">
        <BookOpen size={16} className="text-[#26a69a]" />
        <div className="text-[10px] text-gray-500 tracking-widest">MODELS</div>
      </div>

      <div className="text-xs text-gray-400 leading-relaxed">
        Model 1 is a TDT-based timing model that combines calendar-root timing events with
        real market structure (4H liquidity raids + 15M MSS confirmation) to generate BUY/SELL signals.
        Signals are never generated from timing alone — market structure conditions must actually occur.
      </div>

      {/* Signal Flow */}
      <div className="rounded-lg border border-[#1a1f2e] bg-[#0d1117] p-3">
        <div className="text-[10px] text-gray-500 tracking-widest mb-2">SIGNAL FLOW</div>
        <div className="space-y-1.5">
          {[
            'TDT TIMING',
            'MODEL 1 EVENT',
            '4H REFERENCE RANGE',
            '4H RAID',
            'HTF BIAS',
            '15M SWEEP / STRUCTURE',
            '15M MSS',
            'CONFIRMING CLOSE',
            'BUY / SELL',
          ].map((step, i) => (
            <div key={i} className="flex items-center gap-2">
              <div className="w-5 h-5 rounded-full bg-[#1a1f2e] flex items-center justify-center text-[10px] text-gray-500 font-bold">
                {i + 1}
              </div>
              <div className="text-xs text-gray-300 font-bold">{step}</div>
              {i < 8 && <div className="text-gray-600 text-[10px] ml-auto">↓</div>}
            </div>
          ))}
        </div>
      </div>

      {/* Calendar-Root Model 1 Events */}
      <div className="space-y-2">
        <div className="text-[10px] text-gray-500 tracking-widest">CALENDAR-ROOT MODEL 1 EVENTS</div>
        {ROOT_MAPPINGS_LIST.map((evt) => {
          const id = `root_${evt.root}`;
          const isExpanded = expanded === id;
          return (
            <div key={id} className="rounded-lg border border-[#1a1f2e] bg-[#0d1117] overflow-hidden">
              <button
                onClick={() => setExpanded(isExpanded ? null : id)}
                className="w-full flex items-center justify-between p-3 hover:bg-[#1a1f2e]/50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-[#f59e0b]/10 border border-[#f59e0b]/30 flex items-center justify-center text-[#f59e0b] font-bold text-sm">
                    {evt.root}
                  </div>
                  <div className="text-left">
                    <div className="text-sm font-bold text-gray-200">{evt.ratio}</div>
                    <div className="text-[10px] text-gray-500">{evt.type}</div>
                  </div>
                </div>
                <ChevronRight size={16} className={`text-gray-500 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
              </button>
              {isExpanded && (
                <div className="p-3 pt-0 space-y-2 text-xs">
                  <Row label="Root" value={evt.root.toString()} />
                  <Row label="Ratio" value={evt.ratio} />
                  <Row label="Node" value={`Node ${evt.node}`} />
                  <Row label="SAST Time" value={evt.sastTime} />
                  <Row label="Type" value={evt.type} />
                  <div className="text-[11px] text-gray-500 leading-relaxed pt-2 border-t border-[#1a1f2e]">
                    {evt.description}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Date-Based Model 1 Events */}
      <div className="space-y-2">
        <div className="text-[10px] text-gray-500 tracking-widest">DATE-BASED MODEL 1 EVENTS</div>
        {DATE_EVENTS_LIST.map((evt) => {
          const id = `date_${evt.dateNumber}`;
          const isExpanded = expanded === id;
          return (
            <div key={id} className="rounded-lg border border-[#1a1f2e] bg-[#0d1117] overflow-hidden">
              <button
                onClick={() => setExpanded(isExpanded ? null : id)}
                className="w-full flex items-center justify-between p-3 hover:bg-[#1a1f2e]/50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 font-bold text-sm">
                    {evt.dateNumber}
                  </div>
                  <div className="text-left">
                    <div className="text-sm font-bold text-gray-200">Date {evt.dateNumber}</div>
                    <div className="text-[10px] text-gray-500">{evt.eventType}</div>
                  </div>
                </div>
                <ChevronRight size={16} className={`text-gray-500 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
              </button>
              {isExpanded && (
                <div className="p-3 pt-0 space-y-2 text-xs">
                  <Row label="Date" value={evt.dateNumber.toString()} />
                  <Row label="Event Type" value={evt.eventType} />
                  <Row label="Node" value={`Node ${evt.node}`} />
                  <Row label="SAST Time" value={evt.sastTime} />
                  <Row label="Direction Rule" value={evt.directionRuleLabel} />
                  <div className="text-[11px] text-gray-500 leading-relaxed pt-2 border-t border-[#1a1f2e]">
                    {evt.description}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* 7-Sum */}
      <div className="rounded-lg border border-[#1a1f2e] bg-[#0d1117] p-3">
        <div className="text-[10px] text-gray-500 tracking-widest mb-2">7-SUM HYPOTHESIS</div>
        <div className="text-xs text-gray-400 leading-relaxed">
          A recurring TDT timing relationship where components sum to 7 (e.g., 3+4, 1+6).
          This is an empirical hypothesis, not scientifically proven. The 7-sum alone does NOT
          create a trade — the actual trade direction comes from the market-structure signal engine.
        </div>
      </div>

      {/* Signal States */}
      <div className="rounded-lg border border-[#1a1f2e] bg-[#0d1117] p-3">
        <div className="text-[10px] text-gray-500 tracking-widest mb-2">SIGNAL STATES</div>
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <div className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#26a69a]/20 text-[#26a69a]">BUY</div>
            <span className="text-[11px] text-gray-500">All conditions met — bullish 4H raid + 15M close above 06:00 4H high</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#ef5350]/20 text-[#ef5350]">SELL</div>
            <span className="text-[11px] text-gray-500">All conditions met — bearish Turtle Soup + 15M bearish MSS</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#f59e0b]/20 text-[#f59e0b]">WAITING</div>
            <span className="text-[11px] text-gray-500">TDT event exists but market confirmation not yet occurred</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="px-2 py-0.5 rounded text-[10px] font-bold bg-gray-500/20 text-gray-500">NO SIGNAL</div>
            <span className="text-[11px] text-gray-500">No valid setup exists for the selected date/time</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between">
      <span className="text-gray-500">{label}</span>
      <span className="font-bold text-gray-200">{value}</span>
    </div>
  );
}

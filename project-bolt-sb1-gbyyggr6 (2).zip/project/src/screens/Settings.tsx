import { AppSettings, Timeframe, INSTRUMENTS, TIMEFRAMES } from '@/types';
import { Bell, RotateCcw } from 'lucide-react';

const TIMEZONES = [
  'Africa/Johannesburg',
  'UTC',
  'America/New_York',
  'Europe/London',
  'Asia/Tokyo',
  'Asia/Singapore',
  'Australia/Sydney',
];

export default function SettingsScreen({ settings, onSettingsChange, onReset }: {
  settings: AppSettings;
  onSettingsChange: (partial: Partial<AppSettings>) => void;
  onReset: () => void;
}) {
  return (
    <div className="p-3 space-y-4 max-w-2xl mx-auto">
      <div className="text-[10px] text-gray-500 tracking-widest">SETTINGS</div>

      {/* General */}
      <Section title="GENERAL">
        <SelectRow
          label="Timezone"
          value={settings.timezone}
          options={TIMEZONES}
          onChange={(v) => onSettingsChange({ timezone: v })}
        />
        <SelectRow
          label="Instrument"
          value={settings.instrument}
          options={INSTRUMENTS.map((i) => i.symbol)}
          onChange={(v) => onSettingsChange({ instrument: v })}
        />
        <SelectRow
          label="Default Timeframe"
          value={settings.timeframe}
          options={TIMEFRAMES.map((t) => t.value)}
          labels={TIMEFRAMES.map((t) => t.label)}
          onChange={(v) => onSettingsChange({ timeframe: v as Timeframe })}
        />
        <SelectRow
          label="Theme"
          value={settings.theme}
          options={['dark', 'light']}
          labels={['Dark', 'Light']}
          onChange={(v) => onSettingsChange({ theme: v as 'dark' | 'light' })}
        />
      </Section>

      {/* Chart Visibility */}
      <Section title="CHART VISIBILITY">
        <ToggleRow label="TDT Nodes" value={settings.tdtNodeVisibility} onChange={(v) => onSettingsChange({ tdtNodeVisibility: v })} />
        <ToggleRow label="TDT Open Separators" value={settings.tdtSeparatorVisibility} onChange={(v) => onSettingsChange({ tdtSeparatorVisibility: v })} />
        <ToggleRow label="HTF Panel" value={settings.htfVisibility} onChange={(v) => onSettingsChange({ htfVisibility: v })} />
        <ToggleRow label="FVG" value={settings.fvgVisibility} onChange={(v) => onSettingsChange({ fvgVisibility: v })} />
        <ToggleRow label="Order Blocks" value={settings.obVisibility} onChange={(v) => onSettingsChange({ obVisibility: v })} />
        <ToggleRow label="Sweeps" value={settings.sweepVisibility} onChange={(v) => onSettingsChange({ sweepVisibility: v })} />
        <ToggleRow label="MSS" value={settings.mssVisibility} onChange={(v) => onSettingsChange({ mssVisibility: v })} />
        <ToggleRow label="Signals" value={settings.signalVisibility} onChange={(v) => onSettingsChange({ signalVisibility: v })} />
      </Section>

      {/* HTF Candle Counts */}
      <Section title="HTF CANDLE COUNTS">
        <NumberRow label="4H Candles" value={settings.fourHCandleCount} min={1} max={20} onChange={(v) => onSettingsChange({ fourHCandleCount: v })} />
        <NumberRow label="1D Candles" value={settings.oneDCandleCount} min={1} max={20} onChange={(v) => onSettingsChange({ oneDCandleCount: v })} />
        <NumberRow label="1W Candles" value={settings.oneWCandleCount} min={1} max={20} onChange={(v) => onSettingsChange({ oneWCandleCount: v })} />
        <NumberRow label="HTF Panel Width" value={settings.htfPanelWidth} min={80} max={300} step={10} onChange={(v) => onSettingsChange({ htfPanelWidth: v })} />
      </Section>

      {/* Notifications */}
      <Section title="NOTIFICATIONS">
        <ToggleRow
          label="Enable Notifications"
          value={settings.notifications}
          onChange={(v) => onSettingsChange({ notifications: v })}
        />
        {settings.notifications && (
          <div className="text-[11px] text-gray-500 leading-relaxed pt-1">
            <div className="flex items-center gap-1.5 mb-1">
              <Bell size={12} />
              <span>Planned notifications:</span>
            </div>
            <ul className="list-disc list-inside space-y-0.5 ml-2">
              <li>Tomorrow is a TDT Expansion Day</li>
              <li>Today is a TDT Expansion Day</li>
              <li>Model 1 event approaching</li>
              <li>BUY signal triggered</li>
              <li>SELL signal triggered</li>
            </ul>
            <div className="text-[10px] text-gray-600 mt-2">
              Note: Background notifications require browser permission and may not be supported on all devices.
            </div>
          </div>
        )}
      </Section>

      {/* About */}
      <Section title="ABOUT">
        <div className="text-[11px] text-gray-500 leading-relaxed space-y-1">
          <div><span className="text-gray-400 font-bold">TDT TRADING TERMINAL</span></div>
          <div>Professional dark trading terminal based on the TDT (Time Dilation Theory) calendar/timing system.</div>
          <div className="pt-2">
            <span className="text-gray-400">Data provider:</span> Twelve Data (real OHLC market data)
          </div>
          <div>
            <span className="text-gray-400">Timezone:</span> Africa/Johannesburg (UTC+2) default
          </div>
          <div className="pt-2 text-gray-600">
            No fake signals. No placeholder BUY/SELL. All signals require real market-structure confirmation.
          </div>
        </div>
      </Section>

      {/* Reset */}
      <button
        onClick={onReset}
        className="flex items-center gap-2 text-xs text-gray-500 hover:text-[#ef5350] transition-colors py-2"
      >
        <RotateCcw size={14} />
        Reset to defaults
      </button>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <div className="text-[10px] text-gray-500 tracking-widest">{title}</div>
      <div className="rounded-lg border border-[#1a1f2e] bg-[#0d1117] divide-y divide-[#1a1f2e]">
        {children}
      </div>
    </div>
  );
}

function SelectRow({ label, value, options, labels, onChange }: {
  label: string; value: string; options: string[]; labels?: string[]; onChange: (v: string) => void;
}) {
  return (
    <div className="flex items-center justify-between p-3">
      <span className="text-xs text-gray-300">{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="bg-[#0a0e14] border border-[#1a1f2e] text-gray-200 text-xs rounded px-2 py-1 focus:outline-none focus:border-[#26a69a] min-w-[120px]"
      >
        {options.map((opt, i) => (
          <option key={opt} value={opt}>{labels?.[i] ?? opt}</option>
        ))}
      </select>
    </div>
  );
}

function ToggleRow({ label, value, onChange }: {
  label: string; value: boolean; onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between p-3">
      <span className="text-xs text-gray-300">{label}</span>
      <button
        onClick={() => onChange(!value)}
        className={`relative w-10 h-5 rounded-full transition-colors ${value ? 'bg-[#26a69a]' : 'bg-[#1a1f2e]'}`}
      >
        <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform ${value ? 'left-5' : 'left-0.5'}`} />
      </button>
    </div>
  );
}

function NumberRow({ label, value, min, max, step = 1, onChange }: {
  label: string; value: number; min: number; max: number; step?: number; onChange: (v: number) => void;
}) {
  return (
    <div className="flex items-center justify-between p-3">
      <span className="text-xs text-gray-300">{label}</span>
      <div className="flex items-center gap-2">
        <button
          onClick={() => onChange(Math.max(min, value - step))}
          className="w-6 h-6 rounded bg-[#1a1f2e] text-gray-400 text-sm hover:bg-[#26a69a]/20 hover:text-[#26a69a]"
        >−</button>
        <span className="text-xs text-gray-200 font-bold w-8 text-center tabular-nums">{value}</span>
        <button
          onClick={() => onChange(Math.min(max, value + step))}
          className="w-6 h-6 rounded bg-[#1a1f2e] text-gray-400 text-sm hover:bg-[#26a69a]/20 hover:text-[#26a69a]"
        >+</button>
      </div>
    </div>
  );
}

import { useRef, useEffect, useState, useMemo } from 'react';
import { ZoomIn, ZoomOut, Maximize, Eye, EyeOff } from 'lucide-react';
import { AppSettings, Candle, SignalResult, RaidEvent, MSSEvent, SweepEvent, FVGEvent, OBEvent } from '@/types';
import { useMarketData } from '@/hooks/useMarketData';
import { ChartRenderer, ChartOverlays } from '@/chart/mainChart';
import { renderHTFPanel, calculateHTFTimer, getHTFOpenLevel, HTFData } from '@/chart/floatingHTF';
import { detect4HRaids } from '@/structure/htfRaid';
import { detectMSSFromRaid, detectSwingMSS } from '@/structure/mss';
import { detectSweeps, detectFVGs, detectOrderBlocks } from '@/structure/sweeps';
import { generateLiveSignal } from '@/signals/model1';
import { TIMEFRAMES } from '@/types';

interface ToggleItem {
  key: keyof ChartOverlays;
  label: string;
  settingKey: keyof AppSettings;
}

const TOGGLES: ToggleItem[] = [
  { key: 'tdtSeparators', label: 'TDT SEPARATORS', settingKey: 'tdtSeparatorVisibility' },
  { key: 'tdtNodes', label: 'TDT NODES', settingKey: 'tdtNodeVisibility' },
  { key: 'raids', label: '4H RAIDS', settingKey: 'signalVisibility' },
  { key: 'mssEvents', label: 'MSS', settingKey: 'mssVisibility' },
  { key: 'sweeps', label: 'SWEEPS', settingKey: 'sweepVisibility' },
  { key: 'fvgs', label: 'FVG', settingKey: 'fvgVisibility' },
  { key: 'orderBlocks', label: 'OB', settingKey: 'obVisibility' },
  { key: 'signal', label: 'SIGNALS', settingKey: 'signalVisibility' },
  { key: 'htfOpenLevels', label: 'HTF OPEN', settingKey: 'htfVisibility' },
];

export default function ChartScreen({ settings, onSettingsChange }: {
  settings: AppSettings;
  onSettingsChange: (partial: Partial<AppSettings>) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const htfCanvasRef = useRef<HTMLCanvasElement>(null);
  const rendererRef = useRef<ChartRenderer | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [showToggles, setShowToggles] = useState(false);
  const [now, setNow] = useState(new Date());

  const { loading, error, candles15m, candles4h, candles1d, candles1w } = useMarketData(settings.instrument, settings.timeframe);

  // Update clock for HTF timers
  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Compute overlays
  const overlays: ChartOverlays = useMemo(() => {
    if (candles15m.length === 0 || candles4h.length === 0) return {};

    const raids = detect4HRaids(candles4h, settings.timezone);
    const lastRaid = raids[raids.length - 1];

    const mssEvents: MSSEvent[] = [];
    if (lastRaid) {
      const mss = detectMSSFromRaid(candles15m, lastRaid);
      if (mss) mssEvents.push(mss);
    }
    // Also include swing-based MSS
    const swingMss = detectSwingMSS(candles15m.slice(-100));
    mssEvents.push(...swingMss.slice(-3));

    const sweeps = detectSweeps(candles15m.slice(-100), 5);
    const fvgs = detectFVGs(candles15m.slice(-100));
    const orderBlocks = detectOrderBlocks(candles15m.slice(-100));

    let signal: SignalResult | null = null;
    try {
      signal = generateLiveSignal(candles15m, candles4h, settings.timezone);
    } catch {
      signal = null;
    }

    const htfOpenLevels: { label: string; price: number; color: string }[] = [];
    const fourHOpen = getHTFOpenLevel(candles4h, '4H', '#3b82f6');
    const oneDOpen = getHTFOpenLevel(candles1d, '1D', '#f59e0b');
    const oneWOpen = getHTFOpenLevel(candles1w, '1W', '#8b5cf6');
    if (fourHOpen) htfOpenLevels.push(fourHOpen);
    if (oneDOpen) htfOpenLevels.push(oneDOpen);
    if (oneWOpen) htfOpenLevels.push(oneWOpen);

    return {
      raids: raids.slice(-3),
      mssEvents,
      sweeps: sweeps.slice(-10),
      fvgs: fvgs.slice(-10),
      orderBlocks: orderBlocks.slice(-5),
      signal,
      tdtSeparators: true,
      tdtNodes: true,
      htfOpenLevels,
    };
  }, [candles15m, candles4h, candles1d, candles1w, settings.timezone]);

  // Initialize and render chart
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = container.getBoundingClientRect();
    const htfWidth = settings.htfVisibility ? settings.htfPanelWidth : 0;
    const chartWidth = rect.width - htfWidth;
    const chartHeight = rect.height;

    canvas.width = chartWidth * dpr;
    canvas.height = chartHeight * dpr;
    canvas.style.width = `${chartWidth}px`;
    canvas.style.height = `${chartHeight}px`;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.scale(dpr, dpr);
    // Reset transform for logical pixel coordinate system
    canvas.width = chartWidth * dpr;
    canvas.height = chartHeight * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    if (!rendererRef.current) {
      rendererRef.current = new ChartRenderer(canvas);
      // Override canvas dims for logical coords
      rendererRef.current.setCandles(candles15m);
    } else {
      rendererRef.current.setCandles(candles15m);
    }

    // Set canvas logical dimensions
    // ChartRenderer uses canvas.width/height directly, so set them to logical pixels
    canvas.width = chartWidth;
    canvas.height = chartHeight;

    rendererRef.current.setConfig({
      width: chartWidth,
      height: chartHeight,
      settings,
      timezone: settings.timezone,
      overlays,
    });

    rendererRef.current.render();
  }, [candles15m, settings, overlays]);

  // Render HTF panel
  useEffect(() => {
    const htfCanvas = htfCanvasRef.current;
    if (!htfCanvas || !settings.htfVisibility) return;

    const dpr = window.devicePixelRatio || 1;
    const width = settings.htfPanelWidth;
    const height = htfCanvas.parentElement?.clientHeight ?? 400;

    htfCanvas.width = width;
    htfCanvas.height = height;

    const ctx = htfCanvas.getContext('2d');
    if (!ctx) return;

    const htfData: HTFData = {
      fourH: candles4h,
      oneDay: candles1d,
      oneWeek: candles1w,
    };

    renderHTFPanel(ctx, 0, 0, width, height, htfData, settings);
  }, [candles4h, candles1d, candles1w, settings, now]);

  // Handle resize
  useEffect(() => {
    const handleResize = () => {
      // Force re-render by updating deps
      const canvas = canvasRef.current;
      const container = containerRef.current;
      if (!canvas || !container) return;

      const htfWidth = settings.htfVisibility ? settings.htfPanelWidth : 0;
      const chartWidth = container.getBoundingClientRect().width - htfWidth;
      const chartHeight = container.getBoundingClientRect().height;

      canvas.width = chartWidth;
      canvas.height = chartHeight;

      if (rendererRef.current) {
        rendererRef.current.setConfig({
          width: chartWidth,
          height: chartHeight,
          settings,
          timezone: settings.timezone,
          overlays,
        });
        rendererRef.current.render();
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [settings, overlays]);

  // Touch/mouse interaction
  useEffect(() => {
    const canvas = canvasRef.current;
    const renderer = rendererRef.current;
    if (!canvas || !renderer) return;

    let lastTouchX = 0;
    let lastTouchY = 0;
    let isPanning = false;
    let pinchDistance = 0;

    const handlePointerDown = (e: PointerEvent) => {
      isPanning = true;
      lastTouchX = e.clientX;
      lastTouchY = e.clientY;
      const rect = canvas.getBoundingClientRect();
      renderer.setCrosshair(e.clientX - rect.left, e.clientY - rect.top, true);
      renderer.render();
    };

    const handlePointerMove = (e: PointerEvent) => {
      if (isPanning) {
        const deltaX = e.clientX - lastTouchX;
        renderer.pan(deltaX);
        lastTouchX = e.clientX;
        lastTouchY = e.clientY;
      }
      const rect = canvas.getBoundingClientRect();
      renderer.setCrosshair(e.clientX - rect.left, e.clientY - rect.top, true);
      renderer.render();
    };

    const handlePointerUp = () => {
      isPanning = false;
      renderer.setCrosshair(-1, -1, false);
      renderer.render();
    };

    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      const rect = canvas.getBoundingClientRect();
      renderer.zoom(e.deltaY > 0 ? 10 : -10, e.clientX - rect.left);
      renderer.render();
    };

    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        pinchDistance = Math.sqrt(dx * dx + dy * dy);
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        e.preventDefault();
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        const newDist = Math.sqrt(dx * dx + dy * dy);
        const delta = pinchDistance - newDist;
        renderer.zoom(delta * 2, canvas.width / 2);
        pinchDistance = newDist;
        renderer.render();
      }
    };

    canvas.addEventListener('pointerdown', handlePointerDown);
    canvas.addEventListener('pointermove', handlePointerMove);
    canvas.addEventListener('pointerup', handlePointerUp);
    canvas.addEventListener('pointerleave', handlePointerUp);
    canvas.addEventListener('wheel', handleWheel, { passive: false });
    canvas.addEventListener('touchstart', handleTouchStart, { passive: false });
    canvas.addEventListener('touchmove', handleTouchMove, { passive: false });

    return () => {
      canvas.removeEventListener('pointerdown', handlePointerDown);
      canvas.removeEventListener('pointermove', handlePointerMove);
      canvas.removeEventListener('pointerup', handlePointerUp);
      canvas.removeEventListener('pointerleave', handlePointerUp);
      canvas.removeEventListener('wheel', handleWheel);
      canvas.removeEventListener('touchstart', handleTouchStart);
      canvas.removeEventListener('touchmove', handleTouchMove);
    };
  }, []);

  // HTF timers
  const htfTimers = useMemo(() => {
    return {
      fourH: calculateHTFTimer(candles4h, 4 * 60 * 60 * 1000, '4H'),
      oneDay: calculateHTFTimer(candles1d, 24 * 60 * 60 * 1000, '1D'),
      oneWeek: calculateHTFTimer(candles1w, 7 * 24 * 60 * 60 * 1000, '1W'),
    };
  }, [candles4h, candles1d, candles1w, now]);

  const zoomIn = () => {
    if (rendererRef.current) {
      rendererRef.current.zoom(-20, canvasRef.current?.width ?? 400 / 2);
      rendererRef.current.render();
    }
  };

  const zoomOut = () => {
    if (rendererRef.current) {
      rendererRef.current.zoom(20, canvasRef.current?.width ?? 400 / 2);
      rendererRef.current.render();
    }
  };

  const resetView = () => {
    if (rendererRef.current) {
      rendererRef.current.resetView();
      rendererRef.current.render();
    }
  };

  return (
    <div className="p-2 space-y-2 h-full flex flex-col">
      {/* Chart header */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <select
            value={settings.instrument}
            onChange={(e) => onSettingsChange({ instrument: e.target.value })}
            className="bg-[#0d1117] border border-[#1a1f2e] text-gray-200 text-xs rounded px-2 py-1 focus:outline-none focus:border-[#26a69a]"
          >
            {['BTC/USD', 'ETH/USD', 'SOL/USD', 'BNB/USD', 'XRP/USD', 'XAU/USD'].map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
          <select
            value={settings.timeframe}
            onChange={(e) => onSettingsChange({ timeframe: e.target.value as AppSettings['timeframe'] })}
            className="bg-[#0d1117] border border-[#1a1f2e] text-gray-200 text-xs rounded px-2 py-1 focus:outline-none focus:border-[#26a69a]"
          >
            {TIMEFRAMES.map((tf) => (
              <option key={tf.value} value={tf.value}>{tf.label}</option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-1">
          <button onClick={zoomOut} className="p-1.5 rounded hover:bg-[#1a1f2e] text-gray-400">
            <ZoomOut size={14} />
          </button>
          <button onClick={zoomIn} className="p-1.5 rounded hover:bg-[#1a1f2e] text-gray-400">
            <ZoomIn size={14} />
          </button>
          <button onClick={resetView} className="p-1.5 rounded hover:bg-[#1a1f2e] text-gray-400">
            <Maximize size={14} />
          </button>
          <button
            onClick={() => setShowToggles(!showToggles)}
            className={`p-1.5 rounded ${showToggles ? 'bg-[#26a69a]/20 text-[#26a69a]' : 'hover:bg-[#1a1f2e] text-gray-400'}`}
          >
            {showToggles ? <EyeOff size={14} /> : <Eye size={14} />}
          </button>
        </div>
      </div>

      {/* HTF Timers */}
      <div className="flex gap-2 text-[10px]">
        {htfTimers.fourH && (
          <div className="flex items-center gap-1 text-gray-500">
            <span className="text-blue-400 font-bold">4H</span>
            <span className="tabular-nums">{htfTimers.fourH.closesIn}</span>
          </div>
        )}
        {htfTimers.oneDay && (
          <div className="flex items-center gap-1 text-gray-500">
            <span className="text-[#f59e0b] font-bold">1D</span>
            <span className="tabular-nums">{htfTimers.oneDay.closesIn}</span>
          </div>
        )}
        {htfTimers.oneWeek && (
          <div className="flex items-center gap-1 text-gray-500">
            <span className="text-[#8b5cf6] font-bold">1W</span>
            <span className="tabular-nums">{htfTimers.oneWeek.closesIn}</span>
          </div>
        )}
      </div>

      {/* Toggle panel */}
      {showToggles && (
        <div className="flex flex-wrap gap-1.5 p-2 bg-[#0d1117] border border-[#1a1f2e] rounded-lg">
          {TOGGLES.map((t) => {
            const enabled = settings[t.settingKey as keyof AppSettings] as boolean;
            return (
              <button
                key={t.key}
                onClick={() => onSettingsChange({ [t.settingKey]: !enabled } as Partial<AppSettings>)}
                className={`text-[10px] px-2 py-1 rounded font-bold tracking-wider transition-colors ${
                  enabled
                    ? 'bg-[#26a69a]/20 text-[#26a69a] border border-[#26a69a]/30'
                    : 'bg-[#0a0e14] text-gray-600 border border-[#1a1f2e]'
                }`}
              >
                {t.label}
              </button>
            );
          })}
        </div>
      )}

      {/* Chart + HTF Panel */}
      <div className="flex-1 flex gap-1 min-h-0">
        <div ref={containerRef} className="flex-1 relative bg-[#0a0e14] rounded-lg overflow-hidden border border-[#1a1f2e]">
          {loading && (
            <div className="absolute inset-0 flex items-center justify-center z-10 bg-[#0a0e14]/80">
              <div className="text-xs text-gray-500 animate-pulse">LOADING MARKET DATA...</div>
            </div>
          )}
          {error && !loading && (
            <div className="absolute inset-0 flex items-center justify-center z-10 bg-[#0a0e14]/80">
              <div className="text-xs text-[#ef5350]">MARKET DATA UNAVAILABLE</div>
            </div>
          )}
          <canvas ref={canvasRef} className="block touch-none" />
        </div>

        {settings.htfVisibility && (
          <div className="flex-shrink-0 bg-[#0d1117] rounded-lg overflow-hidden border border-[#1a1f2e]" style={{ width: settings.htfPanelWidth }}>
            <canvas ref={htfCanvasRef} className="block" />
          </div>
        )}
      </div>
    </div>
  );
}

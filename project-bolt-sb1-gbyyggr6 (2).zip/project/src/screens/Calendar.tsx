import { useState, useMemo } from 'react';
import { ChevronLeft, ChevronRight, X } from 'lucide-react';
import { AppSettings, TDTDayInfo } from '@/types';
import { getTDTForDay, calculateTDTDay } from '@/tdt';
import { digitalRoot, isExpansionRoot } from '@/tdt/digitalRoot';
import { getModel1Event, getDateModel1Event, getAllModel1Events } from '@/tdt/model1Timing';

const WEEKDAYS = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
const MONTH_NAMES = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

interface DayCell {
  day: number | null;
  info: TDTDayInfo | null;
  isToday: boolean;
}

export default function CalendarScreen({ settings }: { settings: AppSettings }) {
  const today = new Date();
  const [viewYear, setViewYear] = useState(today.getFullYear());
  const [viewMonth, setViewMonth] = useState(today.getMonth());
  const [selectedDay, setSelectedDay] = useState<number | null>(null);

  const days: DayCell[] = useMemo(() => {
    const firstDay = new Date(viewYear, viewMonth, 1);
    const lastDay = new Date(viewYear, viewMonth + 1, 0);
    const startWeekday = firstDay.getDay();
    const totalDays = lastDay.getDate();

    const cells: DayCell[] = [];
    // Leading blanks
    for (let i = 0; i < startWeekday; i++) {
      cells.push({ day: null, info: null, isToday: false });
    }
    // Days
    const todayInTz = calculateTDTDay(today, settings.timezone);
    for (let d = 1; d <= totalDays; d++) {
      const info = getTDTForDay(viewYear, viewMonth, d, settings.timezone);
      cells.push({
        day: d,
        info,
        isToday: d === todayInTz.dayOfMonth && viewMonth === today.getMonth() && viewYear === today.getFullYear(),
      });
    }
    return cells;
  }, [viewYear, viewMonth, settings.timezone]);

  const selectedInfo = selectedDay ? getTDTForDay(viewYear, viewMonth, selectedDay, settings.timezone) : null;
  const selectedDateEvent = selectedDay ? getDateModel1Event(selectedDay) : null;
  const selectedCalEvents = selectedInfo ? getAllModel1Events(selectedInfo.digitalRoot) : [];

  const prevMonth = () => {
    if (viewMonth === 0) {
      setViewMonth(11);
      setViewYear(viewYear - 1);
    } else {
      setViewMonth(viewMonth - 1);
    }
  };

  const nextMonth = () => {
    if (viewMonth === 11) {
      setViewMonth(0);
      setViewYear(viewYear + 1);
    } else {
      setViewMonth(viewMonth + 1);
    }
  };

  return (
    <div className="p-3 space-y-3">
      <div className="text-[10px] text-gray-500 tracking-widest">CALENDAR</div>

      {/* Month navigation */}
      <div className="flex items-center justify-between">
        <button onClick={prevMonth} className="p-2 rounded-lg hover:bg-[#1a1f2e] text-gray-400">
          <ChevronLeft size={20} />
        </button>
        <div className="text-sm font-bold text-gray-200">
          {MONTH_NAMES[viewMonth]} {viewYear}
        </div>
        <button onClick={nextMonth} className="p-2 rounded-lg hover:bg-[#1a1f2e] text-gray-400">
          <ChevronRight size={20} />
        </button>
      </div>

      {/* Weekday headers */}
      <div className="grid grid-cols-7 gap-1">
        {WEEKDAYS.map((d, i) => (
          <div key={i} className="text-center text-[10px] text-gray-600 font-bold py-1">
            {d}
          </div>
        ))}
      </div>

      {/* Calendar grid */}
      <div className="grid grid-cols-7 gap-1">
        {days.map((cell, i) => {
          if (cell.day === null) {
            return <div key={i} className="aspect-square" />;
          }
          const root = cell.info?.digitalRoot ?? 0;
          const isExpansion = cell.info?.isExpansion ?? false;
          const hasEvent = cell.info?.model1Event !== null || getDateModel1Event(cell.day) !== null;

          return (
            <button
              key={i}
              onClick={() => setSelectedDay(cell.day)}
              className={`aspect-square rounded-lg flex flex-col items-center justify-center transition-all duration-150 relative ${
                cell.isToday
                  ? 'ring-1 ring-[#26a69a]'
                  : ''
              } ${
                isExpansion
                  ? 'bg-[#f59e0b]/10 border border-[#f59e0b]/30 hover:bg-[#f59e0b]/20'
                  : 'bg-[#0d1117] border border-[#1a1f2e] hover:bg-[#1a1f2e]'
              } ${selectedDay === cell.day ? 'ring-2 ring-blue-500' : ''}`}
            >
              <span className={`text-xs font-bold ${isExpansion ? 'text-[#f59e0b]' : 'text-gray-300'}`}>
                {cell.day}
              </span>
              <span className={`text-[8px] ${isExpansion ? 'text-[#f59e0b]/60' : 'text-gray-600'}`}>
                {root}
              </span>
              {hasEvent && (
                <div className={`absolute bottom-0.5 w-1 h-1 rounded-full ${
                  isExpansion ? 'bg-[#f59e0b]' : 'bg-blue-500'
                }`} />
              )}
            </button>
          );
        })}
      </div>

      {/* Legend */}
      <div className="flex items-center gap-4 text-[10px] text-gray-500 pt-2">
        <div className="flex items-center gap-1.5">
          <div className="w-2 h-2 rounded bg-[#f59e0b]/30 border border-[#f59e0b]/50" />
          <span>EXPANSION (1,3,5,7,9)</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-1 h-1 rounded-full bg-blue-500" />
          <span>Model 1 Event</span>
        </div>
      </div>

      {/* Selected day detail */}
      {selectedInfo && (
        <div className="fixed inset-0 bg-black/60 flex items-end sm:items-center justify-center z-50 p-3" onClick={() => setSelectedDay(null)}>
          <div className="bg-[#0d1117] border border-[#1a1f2e] rounded-xl p-4 w-full max-w-md space-y-3" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <div className="text-sm font-bold text-gray-200">
                {MONTH_NAMES[viewMonth]} {selectedDay}, {viewYear}
              </div>
              <button onClick={() => setSelectedDay(null)} className="text-gray-500 hover:text-gray-300">
                <X size={16} />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <DetailCard label="DIGITAL ROOT" value={selectedInfo.digitalRoot.toString()} highlight={selectedInfo.isExpansion} />
              <DetailCard label="EXPANSION" value={selectedInfo.isExpansion ? 'YES' : 'NO'} highlight={selectedInfo.isExpansion} />
              <DetailCard label="RATIO" value={selectedInfo.ratio ?? '—'} />
              <DetailCard label="STATUS" value={selectedInfo.status} />
            </div>

            {/* Calendar-root Model 1 events */}
            {selectedCalEvents.length > 0 && (
              <div className="space-y-2">
                <div className="text-[10px] text-gray-500 tracking-widest">CALENDAR-ROOT MODEL 1</div>
                {selectedCalEvents.map((evt, i) => (
                  <div key={i} className="rounded-lg border border-[#1a1f2e] bg-[#0a0e14] p-2.5 space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="text-gray-500">Ratio</span>
                      <span className="font-bold text-gray-200">{evt.ratio}</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-gray-500">Node</span>
                      <span className="font-bold text-gray-200">Node {evt.node} ({evt.sastTime} SAST)</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-gray-500">Type</span>
                      <span className="font-bold text-[#f59e0b]">{evt.type}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Date-based Model 1 event */}
            {selectedDateEvent && (
              <div className="space-y-2">
                <div className="text-[10px] text-gray-500 tracking-widest">DATE-BASED MODEL 1</div>
                <div className="rounded-lg border border-blue-500/20 bg-blue-500/5 p-2.5 space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-500">Event</span>
                    <span className="font-bold text-blue-400">{selectedDateEvent.eventType}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-500">Node</span>
                    <span className="font-bold text-gray-200">Node {selectedDateEvent.node} ({selectedDateEvent.sastTime} SAST)</span>
                  </div>
                  <div className="text-[11px] text-gray-500 leading-relaxed pt-1">
                    {selectedDateEvent.description}
                  </div>
                </div>
              </div>
            )}

            {/* Signal status */}
            <div className="rounded-lg border border-[#1a1f2e] bg-[#0a0e14] p-2.5">
              <div className="text-[10px] text-gray-500 tracking-widest mb-1">SIGNAL STATUS</div>
              <div className="text-xs text-gray-400">
                {selectedInfo.isExpansion || selectedCalEvents.length > 0 || selectedDateEvent
                  ? 'A valid TDT event exists. Signal direction depends on real market structure (4H raid + 15M MSS). Check the Chart or History tab for actual signal.'
                  : 'No valid TDT setup for this date. NO SIGNAL.'}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function DetailCard({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div className={`rounded-lg border p-2.5 ${highlight ? 'border-[#f59e0b]/30 bg-[#f59e0b]/5' : 'border-[#1a1f2e] bg-[#0a0e14]'}`}>
      <div className="text-[9px] text-gray-500 tracking-widest mb-1">{label}</div>
      <div className={`text-sm font-bold ${highlight ? 'text-[#f59e0b]' : 'text-gray-200'}`}>{value}</div>
    </div>
  );
}

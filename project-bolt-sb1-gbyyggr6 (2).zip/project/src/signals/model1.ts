// ============================================================
// Model 1 Signal Engine
// Combines TDT timing + 4H raid + directional bias + 15M MSS → BUY/SELL
//
// CONCEPT:
//   TDT TIMING → MODEL 1 EVENT → 4H REFERENCE RANGE →
//   4H RAID → DIRECTIONAL BIAS → 15M SWEEP → 15M MSS →
//   CONFIRMING CLOSE → BUY / SELL
//
// The directional bias engine anchors at Node 1 (02:00 SAST) and
// evaluates liquidity sweeps relative to the HTF open before
// Node 12 (13:00 SAST). Expansion phase begins at Node 20 (21:00 SAST).
//
// NO EARLY SIGNAL. NO PREDICTION. NO INVENTED SIGNAL.
// The market-structure conditions must actually occur in real OHLC.
// ============================================================

import { Candle, SignalResult, SignalState, StructureDirection, RaidEvent, MSSEvent, BiasResult } from '@/types';
import { digitalRoot, isExpansionRoot, isSevenSumRatio } from '@/tdt/digitalRoot';
import { getModel1Event, getDateModel1Event, getAllModel1Events } from '@/tdt/model1Timing';
import { detect4HRaids, getHTFBiasFromRaid } from '@/structure/htfRaid';
import { detectMSSFromRaid, detectBullishMSS, detectBearishMSS } from '@/structure/mss';
import { getDayInTimezoneSafe } from './helpers';
import { calculateDirectionalBias } from './bias';

/**
 * Build the ratio string with a static guard for Root 7.
 * Root 7 always displays "7:12" regardless of dateEvent state,
 * preventing "7:undefined" or NaN errors.
 */
function buildRatio(
  root: number,
  model1Event: ReturnType<typeof getModel1Event>,
  dateEvent: ReturnType<typeof getDateModel1Event>
): string | null {
  if (model1Event?.ratio) return model1Event.ratio;
  if (root === 7) return '7:12';
  if (dateEvent) return `${root}:${dateEvent.node}`;
  return null;
}

/**
 * Generate a complete signal analysis for a given date + instrument.
 *
 * @param date The calendar date to analyze
 * @param fifteenMCandles Real 15M OHLC candles
 * @param fourHCandles Real 4H OHLC candles
 * @param timezone TDT timezone
 */
export function generateSignal(
  date: Date,
  fifteenMCandles: Candle[],
  fourHCandles: Candle[],
  timezone: string = 'Africa/Johannesburg'
): SignalResult {
  const dayOfMonth = getDayInTimezoneSafe(date, timezone);
  const root = digitalRoot(dayOfMonth);
  const isExpansion = isExpansionRoot(root);
  const model1Event = getModel1Event(root);
  const dateEvent = getDateModel1Event(dayOfMonth);
  const allCalEvents = getAllModel1Events(root);

  const ratio = buildRatio(root, model1Event, dateEvent);

  const baseResult: SignalResult = {
    state: 'NO_SIGNAL',
    date: new Date(date),
    root,
    ratio,
    node: model1Event?.node ?? dateEvent?.node ?? null,
    eventTime: model1Event?.sastTime ?? dateEvent?.sastTime ?? null,
    htfBias: 'neutral',
    fourHRaid: 'NONE',
    fifteenMSss: 'neutral',
    triggerTime: null,
    triggerPrice: null,
    explanation: '',
  };

  // If no TDT event at all, NO SIGNAL
  if (!model1Event && !dateEvent && !isExpansion) {
    return {
      ...baseResult,
      explanation: 'No TDT Model 1 event or expansion day for this date.',
    };
  }

  // Detect 4H raids
  const raids = detect4HRaids(fourHCandles, timezone);
  const targetDay = dayOfMonth;

  // Find the raid that corresponds to this date
  let relevantRaid: RaidEvent | null = null;
  for (let i = raids.length - 1; i >= 0; i--) {
    const raidDay = getDayInTimezoneSafe(new Date(raids[i].raidTimestamp), timezone);
    if (raidDay === targetDay) {
      relevantRaid = raids[i];
      break;
    }
  }

  // Calculate directional bias from the bias engine
  const bias = calculateDirectionalBias(fifteenMCandles, fourHCandles, timezone, date);

  // If there's a TDT event but no raid, WAITING FOR CONFIRMATION
  if (!relevantRaid) {
    return {
      ...baseResult,
      state: 'WAITING_FOR_CONFIRMATION',
      htfBias: bias.mssDirection,
      explanation: `TDT event exists (root ${root}, ratio ${ratio}). No 4H liquidity raid detected for this date. Directional bias: ${bias.state.toUpperCase()}. ${bias.explanation}`,
    };
  }

  // We have a raid — determine HTF bias from raid
  const raidHtfBias = getHTFBiasFromRaid(relevantRaid);
  const raidType = relevantRaid.raidDirection === 'long'
    ? 'CONFIRMED'
    : relevantRaid.turtleSoup
      ? 'TURTLE SOUP'
      : 'WAITING';

  // Use the bias engine's direction if confirmed, otherwise fall back to raid-based bias
  const effectiveBias: StructureDirection =
    bias.mssConfirmed ? bias.mssDirection : raidHtfBias;

  // Find MSS based on the raid
  const mss = detectMSSFromRaid(fifteenMCandles, relevantRaid);

  if (!mss) {
    return {
      ...baseResult,
      state: 'WAITING_FOR_CONFIRMATION',
      htfBias: effectiveBias,
      fourHRaid: raidType as SignalResult['fourHRaid'],
      explanation: `4H raid detected (${raidType}). Directional bias: ${bias.state.toUpperCase()}. Waiting for 15M MSS confirmation — 15M close ${effectiveBias === 'bullish' ? 'above' : 'below'} the required level.`,
    };
  }

  // MSS confirmed — determine direction based on Model 1 event type
  let signalDirection: StructureDirection = mss.direction;

  // Check for date-based special rules
  if (dateEvent) {
    switch (dateEvent.directionRule) {
      case 'mss_direction':
        signalDirection = mss.direction;
        break;
      case 'counter_trend':
        // Date 4: even day opposes HTF trend
        signalDirection = effectiveBias === 'bullish' ? 'bearish' : 'bullish';
        break;
      case 'preserve_date5':
        // Date 6: continuation of Date 5 — use the same direction
        signalDirection = mss.direction;
        break;
      default:
        signalDirection = mss.direction;
    }
  }

  // Verify the MSS direction matches the required signal direction
  if (signalDirection === 'bullish' && mss.direction === 'bullish') {
    return {
      ...baseResult,
      state: 'BUY',
      htfBias: 'bullish',
      fourHRaid: raidType as SignalResult['fourHRaid'],
      fifteenMSss: 'bullish',
      triggerTime: mss.confirmationTimestamp,
      triggerPrice: mss.confirmationPrice,
      explanation: `BUY signal confirmed. 4H raid (${raidType}) → Directional bias BULLISH → 15M MSS BULLISH → Confirming 15M close above opening range at ${mss.confirmationPrice}. Bias engine: ${bias.explanation}`,
    };
  }

  if (signalDirection === 'bearish' && mss.direction === 'bearish') {
    return {
      ...baseResult,
      state: 'SELL',
      htfBias: 'bearish',
      fourHRaid: raidType as SignalResult['fourHRaid'],
      fifteenMSss: 'bearish',
      triggerTime: mss.confirmationTimestamp,
      triggerPrice: mss.confirmationPrice,
      explanation: `SELL signal confirmed. 4H Turtle Soup raid → Directional bias BEARISH → 15M MSS BEARISH → Confirming 15M close below opening range at ${mss.confirmationPrice}. Bias engine: ${bias.explanation}`,
    };
  }

  // MSS direction doesn't match the required direction
  return {
    ...baseResult,
    state: 'WAITING_FOR_CONFIRMATION',
    htfBias: effectiveBias,
    fourHRaid: raidType as SignalResult['fourHRaid'],
    fifteenMSss: mss.direction,
    explanation: `4H raid confirmed (${raidType}). 15M MSS detected in ${mss.direction} direction, but waiting for confirmation in the required ${signalDirection} direction. Bias: ${bias.state.toUpperCase()}.`,
  };
}

/**
 * Generate a signal for the "today" view — uses current/live data.
 * Same logic but potentially with incomplete candle data (current day in progress).
 */
export function generateLiveSignal(
  fifteenMCandles: Candle[],
  fourHCandles: Candle[],
  timezone: string = 'Africa/Johannesburg'
): SignalResult {
  const now = new Date();
  return generateSignal(now, fifteenMCandles, fourHCandles, timezone);
}

/**
 * Historical signal: reconstruct market state as it existed at a moment.
 * NO LOOK-AHEAD — only uses candles up to the confirmation time.
 */
export function generateHistoricalSignal(
  date: Date,
  fifteenMCandles: Candle[],
  fourHCandles: Candle[],
  timezone: string = 'Africa/Johannesburg'
): SignalResult {
  // Filter candles to only include those that existed up to the end of the target date
  // We add a buffer to the end of the day to allow for confirmation candles
  const dayOfMonth = getDayInTimezoneSafe(date, timezone);

  // Find the timestamp for the end of the target day + 1 day buffer for late confirmations
  const endOfDate = new Date(date);
  endOfDate.setHours(endOfDate.getHours() + 26); // buffer for late confirmations

  const filtered15M = fifteenMCandles.filter((c) => c.timestamp <= endOfDate.getTime());
  const filtered4H = fourHCandles.filter((c) => c.timestamp <= endOfDate.getTime());

  return generateSignal(date, filtered15M, filtered4H, timezone);
}

// ============================================================
// Directional Bias Calculation Engine
//
// Determines the directional bias for the current TDT cycle
// based on liquidity sweeps relative to the Node 1 / HTF open
// (02:00 SAST) and subsequent market structure shifts.
//
// BULLISH BIAS:
//   Price sweeps sell-side liquidity below Node 1 / HTF open
//   prior to Node 12 (13:00 SAST), then reclaims the opening
//   range with a bullish MSS.
//
// BEARISH BIAS:
//   Price sweeps buy-side liquidity above Node 1 / HTF open
//   prior to Node 12 (13:00 SAST), then rejects with a bearish MSS.
//
// NEUTRAL / EXPANSION:
//   If no liquidity sweep occurs by Node 12, maintain neutral
//   bias until Node 20 (21:00 SAST) expansion.
// ============================================================

import { Candle, BiasResult, BiasState, StructureDirection } from '@/types';
import { getCurrentNode, getHourInTimezone, nodeToHour, NODE_12_HOUR, NODE_20_HOUR } from '@/tdt/nodeEngine';
import { detectBullishMSS, detectBearishMSS } from '@/structure/mss';

const CYCLE_ANCHOR_HOUR = 2; // 02:00 SAST = Node 1

/**
 * Find the HTF open candle — the 4H candle whose SAST hour is 02:00.
 * This is the Node 1 / cycle anchor candle.
 */
function findHTFOpenCandle(fourHCandles: Candle[], timezone: string): Candle | null {
  for (const candle of fourHCandles) {
    const hour = getHourInTimezone(new Date(candle.timestamp), timezone);
    if (hour === CYCLE_ANCHOR_HOUR) {
      return candle;
    }
  }
  // Fallback: use the most recent candle before 06:00 SAST
  for (const candle of fourHCandles) {
    const hour = getHourInTimezone(new Date(candle.timestamp), timezone);
    if (hour >= 0 && hour < 6) {
      return candle;
    }
  }
  return null;
}

/**
 * Find the 15M candle at or just after 02:00 SAST for the current cycle.
 * This is the Node 1 open candle on the 15M timeframe.
 */
function findNode1OpenCandle(fifteenMCandles: Candle[], timezone: string): Candle | null {
  for (const candle of fifteenMCandles) {
    const hour = getHourInTimezone(new Date(candle.timestamp), timezone);
    if (hour === CYCLE_ANCHOR_HOUR) {
      const minute = new Intl.DateTimeFormat('en-US', {
        timeZone: timezone,
        minute: 'numeric',
      }).format(new Date(candle.timestamp));
      if (parseInt(minute, 10) === 0) {
        return candle;
      }
    }
  }
  return null;
}

/**
 * Get the opening range high and low from the Node 1 candle.
 * The opening range is defined by the HTF open candle's high and low.
 */
function getOpeningRange(htfOpenCandle: Candle): { high: number; low: number; open: number } {
  return {
    high: htfOpenCandle.high,
    low: htfOpenCandle.low,
    open: htfOpenCandle.open,
  };
}

/**
 * Detect a sell-side liquidity sweep below the HTF open low.
 * A sell-side sweep means price wicks below the opening range low
 * but closes back above it (liquidity grab below).
 */
function detectSellSideSweep(
  fifteenMCandles: Candle[],
  openRangeLow: number,
  node1Timestamp: number,
  node12Timestamp: number
): { swept: boolean; sweepCandle: Candle | null } {
  for (const candle of fifteenMCandles) {
    if (candle.timestamp < node1Timestamp) continue;
    if (candle.timestamp >= node12Timestamp) break;
    if (candle.low < openRangeLow && candle.close > openRangeLow) {
      return { swept: true, sweepCandle: candle };
    }
  }
  return { swept: false, sweepCandle: null };
}

/**
 * Detect a buy-side liquidity sweep above the HTF open high.
 * A buy-side sweep means price wicks above the opening range high
 * but closes back below it (liquidity grab above).
 */
function detectBuySideSweep(
  fifteenMCandles: Candle[],
  openRangeHigh: number,
  node1Timestamp: number,
  node12Timestamp: number
): { swept: boolean; sweepCandle: Candle | null } {
  for (const candle of fifteenMCandles) {
    if (candle.timestamp < node1Timestamp) continue;
    if (candle.timestamp >= node12Timestamp) break;
    if (candle.high > openRangeHigh && candle.close < openRangeHigh) {
      return { swept: true, sweepCandle: candle };
    }
  }
  return { swept: false, sweepCandle: null };
}

/**
 * Build a timestamp for a specific SAST hour on the current cycle day.
 */
function buildSastTimestamp(baseDate: Date, targetHour: number, timezone: string): number {
  const tzTime = new Intl.DateTimeFormat('en-US', {
    timeZone: timezone,
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
    hour: 'numeric',
    minute: 'numeric',
    hour12: false,
  }).formatToParts(baseDate);

  const map: Record<string, number> = {};
  for (const p of tzTime) {
    if (p.type !== 'literal' && p.type !== 'weekday') {
      map[p.type] = parseInt(p.value, 10);
    }
  }

  // Build UTC timestamp for the target SAST hour
  // SAST = UTC+2, so UTC = SAST - 2
  const utcHour = (targetHour - 2 + 24) % 24;
  return Date.UTC(map.year, map.month - 1, map.day, utcHour, 0, 0);
}

/**
 * Calculate the directional bias for the current cycle.
 *
 * @param fifteenMCandles Real 15M OHLC candles
 * @param fourHCandles Real 4H OHLC candles
 * @param timezone TDT timezone (default: Africa/Johannesburg)
 * @param now Current time (for node calculation)
 */
export function calculateDirectionalBias(
  fifteenMCandles: Candle[],
  fourHCandles: Candle[],
  timezone: string = 'Africa/Johannesburg',
  now: Date = new Date()
): BiasResult {
  const currentNode = getCurrentNode(now, timezone);
  const preNode12 = currentNode < 12;
  const postNode20 = currentNode >= 20;
  const node12Hour = nodeToHour(12); // 13:00 SAST
  const node20Hour = nodeToHour(20); // 21:00 SAST

  // Find HTF open candle (02:00 SAST 4H candle = Node 1)
  const htfOpenCandle = findHTFOpenCandle(fourHCandles, timezone);

  if (!htfOpenCandle || fifteenMCandles.length === 0) {
    return {
      state: 'neutral',
      sweepDirection: 'none',
      sweepTime: null,
      sweepPrice: null,
      mssConfirmed: false,
      mssDirection: 'neutral',
      currentNode,
      preNode12,
      postNode20,
      htfOpen: htfOpenCandle?.open ?? null,
      htfOpenTime: htfOpenCandle?.timestamp ?? null,
      explanation: 'No HTF open candle found for the current cycle. Waiting for Node 1 (02:00 SAST) formation.',
    };
  }

  const openRange = getOpeningRange(htfOpenCandle);
  const htfOpen = htfOpenCandle.open;
  const htfOpenTime = htfOpenCandle.timestamp;

  // Find the 15M Node 1 candle to get the start timestamp
  const node1Candle = findNode1OpenCandle(fifteenMCandles, timezone);
  const node1Timestamp = node1Candle?.timestamp ?? htfOpenTime;

  // Build the Node 12 (13:00 SAST) timestamp for the current cycle
  const node12Timestamp = buildSastTimestamp(now, node12Hour, timezone);
  const node20Timestamp = buildSastTimestamp(now, node20Hour, timezone);

  // Check for sell-side sweep (bullish trigger) below opening range low
  const sellSweep = detectSellSideSweep(fifteenMCandles, openRange.low, node1Timestamp, node12Timestamp);

  // Check for buy-side sweep (bearish trigger) above opening range high
  const buySweep = detectBuySideSweep(fifteenMCandles, openRange.high, node1Timestamp, node12Timestamp);

  // Determine sweep result
  let sweepDirection: 'sell_side' | 'buy_side' | 'none' = 'none';
  let sweepCandle: Candle | null = null;

  if (sellSweep.swept && sellSweep.sweepCandle) {
    sweepDirection = 'sell_side';
    sweepCandle = sellSweep.sweepCandle;
  } else if (buySweep.swept && buySweep.sweepCandle) {
    sweepDirection = 'buy_side';
    sweepCandle = buySweep.sweepCandle;
  }

  // No sweep detected yet
  if (sweepDirection === 'none') {
    if (preNode12) {
      return {
        state: 'neutral',
        sweepDirection: 'none',
        sweepTime: null,
        sweepPrice: null,
        mssConfirmed: false,
        mssDirection: 'neutral',
        currentNode,
        preNode12,
        postNode20,
        htfOpen,
        htfOpenTime,
        explanation: `No liquidity sweep detected yet. Node ${currentNode} active — waiting for sweep before Node 12 (13:00 SAST). Bias: NEUTRAL.`,
      };
    }

    if (currentNode >= 12 && currentNode < 20) {
      return {
        state: 'neutral',
        sweepDirection: 'none',
        sweepTime: null,
        sweepPrice: null,
        mssConfirmed: false,
        mssDirection: 'neutral',
        currentNode,
        preNode12: false,
        postNode20: false,
        htfOpen,
        htfOpenTime,
        explanation: `No sweep by Node 12 (13:00 SAST). Maintaining neutral bias until Node 20 (21:00 SAST) expansion phase.`,
      };
    }

    // Post Node 20 — expansion phase
    return {
      state: 'expansion',
      sweepDirection: 'none',
      sweepTime: null,
      sweepPrice: null,
      mssConfirmed: false,
      mssDirection: 'neutral',
      currentNode,
      preNode12: false,
      postNode20: true,
      htfOpen,
      htfOpenTime,
      explanation: `Past Node 20 (21:00 SAST) with no pre-Node-12 sweep. Entering EXPANSION phase. Late-session liquidity expansion may occur.`,
    };
  }

  // Sweep detected — check for MSS confirmation
  const sweepTimestamp = sweepCandle!.timestamp;

  if (sweepDirection === 'sell_side') {
    // Bullish bias: sweep below open range low → look for bullish MSS
    // MSS confirmation: 15M close above the HTF open high
    const mss = detectBullishMSS(fifteenMCandles, openRange.high, sweepTimestamp);

    if (mss) {
      return {
        state: 'bullish',
        sweepDirection: 'sell_side',
        sweepTime: sweepTimestamp,
        sweepPrice: sweepCandle!.low,
        mssConfirmed: true,
        mssDirection: 'bullish',
        currentNode,
        preNode12,
        postNode20,
        htfOpen,
        htfOpenTime,
        explanation: `BULLISH bias confirmed. Sell-side liquidity swept below Node 1 open (low: ${openRange.low}) at ${new Date(sweepTimestamp).toISOString()}. Bullish MSS confirmed — 15M close above opening range high (${openRange.high}) at ${mss.confirmationPrice}.`,
      };
    }

    // Sweep occurred but no MSS yet
    const mssDir: StructureDirection = 'bullish';
    return {
      state: 'neutral',
      sweepDirection: 'sell_side',
      sweepTime: sweepTimestamp,
      sweepPrice: sweepCandle!.low,
      mssConfirmed: false,
      mssDirection: mssDir,
      currentNode,
      preNode12,
      postNode20,
      htfOpen,
      htfOpenTime,
      explanation: `Sell-side liquidity swept below Node 1 open (low: ${openRange.low}). Waiting for bullish MSS — 15M close above opening range high (${openRange.high}).`,
    };
  }

  // Buy-side sweep → bearish bias
  const mss = detectBearishMSS(fifteenMCandles, openRange.low, sweepTimestamp);

  if (mss) {
    return {
      state: 'bearish',
      sweepDirection: 'buy_side',
      sweepTime: sweepTimestamp,
      sweepPrice: sweepCandle!.high,
      mssConfirmed: true,
      mssDirection: 'bearish',
      currentNode,
      preNode12,
      postNode20,
      htfOpen,
      htfOpenTime,
      explanation: `BEARISH bias confirmed. Buy-side liquidity swept above Node 1 open (high: ${openRange.high}) at ${new Date(sweepTimestamp).toISOString()}. Bearish MSS confirmed — 15M close below opening range low (${openRange.low}) at ${mss.confirmationPrice}.`,
    };
  }

  // Sweep but no bearish MSS yet
  return {
    state: 'neutral',
    sweepDirection: 'buy_side',
    sweepTime: sweepTimestamp,
    sweepPrice: sweepCandle!.high,
    mssConfirmed: false,
    mssDirection: 'bearish',
    currentNode,
    preNode12,
    postNode20,
    htfOpen,
    htfOpenTime,
    explanation: `Buy-side liquidity swept above Node 1 open (high: ${openRange.high}). Waiting for bearish MSS — 15M close below opening range low (${openRange.low}).`,
  };
}

// Small helper shared by structure/signal modules.

export function getDayInTimezoneSafe(date: Date, timezone: string): number {
  try {
    const str = new Intl.DateTimeFormat('en-US', {
      timeZone: timezone,
      day: 'numeric',
    }).format(date);
    return parseInt(str, 10);
  } catch {
    return date.getUTCDate();
  }
}

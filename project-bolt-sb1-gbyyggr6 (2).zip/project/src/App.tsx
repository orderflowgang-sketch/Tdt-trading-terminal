import { useState } from 'react';
import { Home, Calendar, CandlestickChart, History, BookOpen, Settings as SettingsIcon } from 'lucide-react';
import { useSettings } from '@/hooks/useSettings';
import TodayScreen from '@/screens/Today';
import CalendarScreen from '@/screens/Calendar';
import ChartScreen from '@/screens/Chart';
import HistoryScreen from '@/screens/History';
import ModelsScreen from '@/screens/Models';
import SettingsScreen from '@/screens/Settings';

type Tab = 'today' | 'calendar' | 'chart' | 'history' | 'models' | 'settings';

const TABS: { id: Tab; label: string; icon: typeof Home }[] = [
  { id: 'today', label: 'TODAY', icon: Home },
  { id: 'calendar', label: 'CALENDAR', icon: Calendar },
  { id: 'chart', label: 'CHART', icon: CandlestickChart },
  { id: 'history', label: 'HISTORY', icon: History },
  { id: 'models', label: 'MODELS', icon: BookOpen },
  { id: 'settings', label: 'SETTINGS', icon: SettingsIcon },
];

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('today');
  const { settings, update, reset, loaded } = useSettings();

  if (!loaded) {
    return (
      <div className="min-h-screen bg-[#0a0e14] flex items-center justify-center">
        <div className="text-gray-500 font-mono text-sm animate-pulse">INITIALIZING TDT TERMINAL...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0e14] text-gray-200 flex flex-col font-mono">
      {/* Header */}
      <header className="flex-shrink-0 border-b border-[#1a1f2e] bg-[#0d1117] px-3 py-2 sm:px-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-[#26a69a] animate-pulse" />
            <h1 className="text-xs sm:text-sm font-bold tracking-wider text-gray-300">
              TDT TRADING TERMINAL
            </h1>
          </div>
          <div className="text-[10px] sm:text-xs text-gray-500">
            {settings.instrument}
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 overflow-y-auto pb-16 max-w-7xl mx-auto w-full">
        {activeTab === 'today' && <TodayScreen settings={settings} />}
        {activeTab === 'calendar' && <CalendarScreen settings={settings} />}
        {activeTab === 'chart' && <ChartScreen settings={settings} onSettingsChange={update} />}
        {activeTab === 'history' && <HistoryScreen settings={settings} />}
        {activeTab === 'models' && <ModelsScreen settings={settings} />}
        {activeTab === 'settings' && (
          <SettingsScreen settings={settings} onSettingsChange={update} onReset={reset} />
        )}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-[#0d1117] border-t border-[#1a1f2e] z-50">
        <div className="flex justify-around items-stretch max-w-7xl mx-auto">
          {TABS.map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex flex-col items-center justify-center gap-1 py-2 px-1 sm:px-3 transition-colors duration-200 ${
                  active
                    ? 'text-[#26a69a] border-t-2 border-[#26a69a]'
                    : 'text-gray-600 border-t-2 border-transparent hover:text-gray-400'
                }`}
                style={{ minWidth: '16%' }}
              >
                <Icon size={18} strokeWidth={active ? 2.5 : 2} />
                <span className="text-[9px] sm:text-[10px] font-semibold tracking-wider">
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

export default App;

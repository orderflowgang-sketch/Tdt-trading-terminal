// ============================================================
// MSS (Market Structure Shift) Engine
// Uses actual 15M OHLC structure to detect MSS.
//
// No RSI, MACD, moving averages, or unrelated indicators.
// No look-ahead — historical MSS only uses info available at that time.
//
// Bullish MSS:
//   15M structure shifts bullish after the liquidity event
//   and the confirming candle closes through the required bullish level.
//   Key confirmation: 15M close above the 06:00 4H high.
//
// Bearish MSS:
//   15M structure shifts bearish after the bearish Turtle Soup rejection
//   and bearish 15M MSS confirmation.
// ============================================================

import { Candle, MSSEvent, StructureDirection, RaidEvent } from '@/types';

/**
 * Identify swing highs and lows in a series of candles.
 * A swing high is a candle whose high is higher than N candles on each side.
 * A swing low is a candle whose low is lower than N candles on each side.
 */
export interface SwingPoint {
  type: 'high' | 'low';
  price: number;
  timestamp: number;
  candleIndex: number;
}

export function findSwings(candles: Candle[], lookback: number = 3): SwingPoint[] {
  const swings: SwingPoint[] = [];
  for (let i = lookback; i < candles.length - lookback; i++) {
    const candle = candles[i];
    let isHigh = true;
    let isLow = true;

    for (let j = 1; j <= lookback; j++) {
      if (candles[i - j].high >= candle.high || candles[i + j].high >= candle.high) {
        isHigh = false;
      }
      if (candles[i - j].low <= candle.low || candles[i + j].low <= candle.low) {
        isLow = false;
      }
    }

    if (isHigh) {
      swings.push({ type: 'high', price: candle.high, timestamp: candle.timestamp, candleIndex: i });
    }
    if (isLow) {
      swings.push({ type: 'low', price: candle.low, timestamp: candle.timestamp, candleIndex: i });
    }
  }
  return swings;
}

/**
 * Detect bullish MSS: a 15M candle closes above a recent swing high
 * (or above the 06:00 4H high in the raid-based context).
 *
 * Bullish confirmation:
 *   15M close above the 06:00 4H HIGH
 */
export function detectBullishMSS(
  fifteenMCandles: Candle[],
  breakLevel: number,
  afterTimestamp: number
): MSSEvent | null {
  // Find the first 15M candle after the raid that closes above the break level
  for (const candle of fifteenMCandles) {
    if (candle.timestamp <= afterTimestamp) continue;
    if (candle.close > breakLevel) {
      return {
        direction: 'bullish',
        breakLevel,
        confirmationCandle: candle,
        confirmationTimestamp: candle.timestamp,
        confirmationPrice: candle.close,
        structureState: 'BULLISH MSS — Close above 06:00 4H High',
      };
    }
  }
  return null;
}

/**
 * Detect bearish MSS: a 15M candle closes below a recent swing low.
 *
 * Bearish confirmation follows the bearish Turtle Soup rejection.
 * The key bearish level is the 02:00 4H LOW (the bottom of the reference range).
 * After the Turtle Soup rejection (06:00 candle raids high but closes back inside),
 * we wait for a 15M close below the reference low.
 */
export function detectBearishMSS(
  fifteenMCandles: Candle[],
  breakLevel: number,
  afterTimestamp: number
): MSSEvent | null {
  for (const candle of fifteenMCandles) {
    if (candle.timestamp <= afterTimestamp) continue;
    if (candle.close < breakLevel) {
      return {
        direction: 'bearish',
        breakLevel,
        confirmationCandle: candle,
        confirmationTimestamp: candle.timestamp,
        confirmationPrice: candle.close,
        structureState: 'BEARISH MSS — Close below reference low',
      };
    }
  }
  return null;
}

/**
 * Detect MSS based on a 4H raid event.
 * Uses the raid context to determine the required break level and direction.
 *
 * Bullish: 15M close above 06:00 4H HIGH
 * Bearish: 15M close below 02:00 4H LOW (after Turtle Soup)
 */
export function detectMSSFromRaid(
  fifteenMCandles: Candle[],
  raid: RaidEvent
): MSSEvent | null {
  if (raid.raidDirection === 'long') {
    // Bullish: 15M close above the 06:00 4H HIGH
    const breakLevel = raid.raidCandle.high;
    return detectBullishMSS(fifteenMCandles, breakLevel, raid.raidTimestamp);
  }

  if (raid.raidDirection === 'short' && raid.turtleSoup) {
    // Bearish Turtle Soup: 15M close below the 02:00 4H LOW
    const breakLevel = raid.referenceCandle.low;
    return detectBearishMSS(fifteenMCandles, breakLevel, raid.raidTimestamp);
  }

  return null;
}

/**
 * Detect MSS purely from 15M swing structure (for general structure analysis).
 * This identifies structure shifts based on swing point breaks.
 */
export function detectSwingMSS(
  candles: Candle[],
  upToIndex?: number
): MSSEvent[] {
  const limit = upToIndex ?? candles.length;
  const swings = findSwings(candles.slice(0, limit), 3);
  const events: MSSEvent[] = [];

  let lastSwingHigh: SwingPoint | null = null;
  let lastSwingLow: SwingPoint | null = null;
  let structureDirection: StructureDirection = 'neutral';

  for (let i = 0; i < limit; i++) {
    const candle = candles[i];

    // Track most recent confirmed swings
    for (const sw of swings) {
      if (sw.candleIndex < i - 3) {
        if (sw.type === 'high' && (!lastSwingHigh || sw.timestamp > lastSwingHigh.timestamp)) {
          lastSwingHigh = sw;
        }
        if (sw.type === 'low' && (!lastSwingLow || sw.timestamp > lastSwingLow.timestamp)) {
          lastSwingLow = sw;
        }
      }
    }

    // Bullish MSS: close above last swing high
    if (lastSwingHigh && candle.close > lastSwingHigh.price && structureDirection !== 'bullish') {
      structureDirection = 'bullish';
      events.push({
        direction: 'bullish',
        breakLevel: lastSwingHigh.price,
        confirmationCandle: candle,
        confirmationTimestamp: candle.timestamp,
        confirmationPrice: candle.close,
        structureState: 'BULLISH MSS — Swing high broken',
      });
    }

    // Bearish MSS: close below last swing low
    if (lastSwingLow && candle.close < lastSwingLow.price && structureDirection !== 'bearish') {
      structureDirection = 'bearish';
      events.push({
        direction: 'bearish',
        breakLevel: lastSwingLow.price,
        confirmationCandle: candle,
        confirmationTimestamp: candle.timestamp,
        confirmationPrice: candle.close,
        structureState: 'BEARISH MSS — Swing low broken',
      });
    }
  }

  return events;
}

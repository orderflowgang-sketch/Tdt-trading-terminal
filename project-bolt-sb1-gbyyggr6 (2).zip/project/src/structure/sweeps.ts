// ============================================================
// Sweeps, Order Blocks, and FVG Detection
// All use real OHLC data. No look-ahead.
// ============================================================

import { Candle, SweepEvent, FVGEvent, OBEvent } from '@/types';
import { findSwings, type SwingPoint } from './mss';

/**
 * Detect liquidity sweeps in a candle series.
 * A sweep occurs when a candle wicks beyond a prior swing point
 * but closes back inside.
 */
export function detectSweeps(candles: Candle[], lookback: number = 5): SweepEvent[] {
  const sweeps: SweepEvent[] = [];
  const swings = findSwings(candles, lookback);

  for (let i = 0; i < candles.length; i++) {
    const candle = candles[i];

    for (const sw of swings) {
      if (sw.candleIndex >= i) continue; // no look-ahead

      // Bullish sweep: wick below swing low, close above
      if (sw.type === 'low' && candle.low < sw.price && candle.close > sw.price) {
        sweeps.push({
          direction: 'bullish',
          level: sw.price,
          candle,
          timestamp: candle.timestamp,
        });
      }

      // Bearish sweep: wick above swing high, close below
      if (sw.type === 'high' && candle.high > sw.price && candle.close < sw.price) {
        sweeps.push({
          direction: 'bearish',
          level: sw.price,
          candle,
          timestamp: candle.timestamp,
        });
      }
    }
  }

  return sweeps;
}

/**
 * Detect Fair Value Gaps (FVG).
 * Bullish FVG: candle[i-1].high < candle[i+1].low (gap up)
 * Bearish FVG: candle[i-1].low > candle[i+1].high (gap down)
 */
export function detectFVGs(candles: Candle[]): FVGEvent[] {
  const fvgs: FVGEvent[] = [];

  for (let i = 1; i < candles.length - 1; i++) {
    const prev = candles[i - 1];
    const next = candles[i + 1];

    // Bullish FVG: gap between prev.high and next.low
    if (next.low > prev.high) {
      fvgs.push({
        direction: 'bullish',
        top: next.low,
        bottom: prev.high,
        startTimestamp: prev.timestamp,
        endTimestamp: next.timestamp,
      });
    }

    // Bearish FVG: gap between prev.low and next.high
    if (next.high < prev.low) {
      fvgs.push({
        direction: 'bearish',
        top: prev.low,
        bottom: next.high,
        startTimestamp: prev.timestamp,
        endTimestamp: next.timestamp,
      });
    }
  }

  return fvgs;
}

/**
 * Detect Order Blocks.
 * Bullish OB: last bearish candle before a strong bullish move
 * Bearish OB: last bullish candle before a strong bearish move
 */
export function detectOrderBlocks(
  candles: Candle[],
  displacementThreshold: number = 1.5
): OBEvent[] {
  const obs: OBEvent[] = [];

  for (let i = 1; i < candles.length - 1; i++) {
    const prev = candles[i - 1];
    const current = candles[i];
    const next = candles[i + 1];

    // Average range for displacement calculation
    const avgRange = candles
      .slice(Math.max(0, i - 10), i)
      .reduce((sum, c) => sum + (c.high - c.low), 0) / Math.min(10, i);
    const displacement = avgRange > 0 ? (next.high - next.low) / avgRange : 1;

    // Bullish OB: last bearish candle before bullish displacement
    if (prev.close < prev.open && next.close > next.open && displacement > displacementThreshold) {
      obs.push({
        direction: 'bullish',
        top: prev.high,
        bottom: prev.low,
        timestamp: prev.timestamp,
      });
    }

    // Bearish OB: last bullish candle before bearish displacement
    if (prev.close > prev.open && next.close < next.open && displacement > displacementThreshold) {
      obs.push({
        direction: 'bearish',
        top: prev.high,
        bottom: prev.low,
        timestamp: prev.timestamp,
      });
    }
  }

  return obs;
}

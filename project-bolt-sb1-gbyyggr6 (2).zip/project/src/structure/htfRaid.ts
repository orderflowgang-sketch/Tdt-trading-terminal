// ============================================================
// 4H Raid Engine
// Detects 4H liquidity raids using REAL OHLC data.
//
// LONG RAID: 06:00 4H candle LOW < 02:00 4H candle LOW
//   → 06:00 candle raided the 02:00 low
//
// SHORT / TURTLE SOUP RAID: 06:00 4H candle HIGH > 02:00 4H candle HIGH
//   → 06:00 candle raided the 02:00 high
//
// The engine preserves:
//   reference candle, raid candle, raided level,
//   raid direction, raid timestamp
// ============================================================

import { Candle, RaidEvent, StructureDirection } from '@/types';
import { getHourInTimezone } from '@/tdt/nodeEngine';

/**
 * Find the 4H candle that starts at a specific SAST hour.
 * 4H candles from Twelve Data are aligned to exchange hours.
 * We need to find the candle whose timestamp maps to the target SAST hour.
 */
function find4HCandleBySastHour(candles: Candle[], targetHour: number, timezone: string): Candle | null {
  for (const candle of candles) {
    const hour = getHourInTimezone(new Date(candle.timestamp), timezone);
    if (hour === targetHour) {
      return candle;
    }
  }
  return null;
}

/**
 * Detect 4H liquidity raid events.
 * The reference candle is the 02:00 SAST 4H candle.
 * The raid candle is the 06:00 SAST 4H candle.
 *
 * We look for the most recent occurrence of this pattern in the candle array.
 */
export function detect4HRaids(
  fourHCandles: Candle[],
  timezone: string = 'Africa/Johannesburg'
): RaidEvent[] {
  const raids: RaidEvent[] = [];

  // We need at least 2 candles
  if (fourHCandles.length < 2) return raids;

  // Walk through candles looking for 02:00 → 06:00 pairs
  for (let i = 0; i < fourHCandles.length - 1; i++) {
    const candle = fourHCandles[i];
    const hour = getHourInTimezone(new Date(candle.timestamp), timezone);

    // Check if this is a 02:00 SAST candle
    if (hour !== 2) continue;

    const referenceCandle = candle;

    // Find the next 4H candle (should be 06:00 SAST)
    const nextCandle = fourHCandles[i + 1];
    const nextHour = getHourInTimezone(new Date(nextCandle.timestamp), timezone);

    if (nextHour !== 6) continue;

    const raidCandle = nextCandle;

    // Check for long raid: 06:00 LOW < 02:00 LOW
    if (raidCandle.low < referenceCandle.low) {
      const turtleSoup = raidCandle.close > referenceCandle.low; // closed back inside
      raids.push({
        referenceCandle,
        raidCandle,
        raidedLevel: 'low',
        raidDirection: 'long',
        raidTimestamp: raidCandle.timestamp,
        raidPrice: raidCandle.low,
        turtleSoup,
      });
    }

    // Check for short raid: 06:00 HIGH > 02:00 HIGH
    if (raidCandle.high > referenceCandle.high) {
      const turtleSoup = raidCandle.close < referenceCandle.high; // closed back inside
      raids.push({
        referenceCandle,
        raidCandle,
        raidedLevel: 'high',
        raidDirection: 'short',
        raidTimestamp: raidCandle.timestamp,
        raidPrice: raidCandle.high,
        turtleSoup,
      });
    }
  }

  return raids;
}

/**
 * Get the most recent 4H raid (for the "today" view).
 */
export function getMostRecentRaid(
  fourHCandles: Candle[],
  timezone: string = 'Africa/Johannesburg'
): RaidEvent | null {
  const raids = detect4HRaids(fourHCandles, timezone);
  return raids.length > 0 ? raids[raids.length - 1] : null;
}

/**
 * Get the 4H raid that occurred on a specific date.
 */
export function getRaidForDate(
  fourHCandles: Candle[],
  targetDate: Date,
  timezone: string = 'Africa/Johannesburg'
): RaidEvent | null {
  const raids = detect4HRaids(fourHCandles, timezone);
  const targetDay = getDayInTimezoneSafe(targetDate, timezone);

  for (let i = raids.length - 1; i >= 0; i--) {
    const raidDay = getDayInTimezoneSafe(new Date(raids[i].raidTimestamp), timezone);
    if (raidDay === targetDay) {
      return raids[i];
    }
  }
  return null;
}

function getDayInTimezoneSafe(date: Date, timezone: string): number {
  try {
    const str = new Intl.DateTimeFormat('en-US', {
      timeZone: timezone,
      day: 'numeric',
    }).format(date);
    return parseInt(str, 10);
  } catch {
    return date.getUTCDate();
  }
}

/**
 * Determine HTF bias from a raid event.
 *
 * Bullish setup:
 *   02:00 4H candle = reference
 *   06:00 4H candle raids below 02:00 low (long raid)
 *   Price must demonstrate bullish reaction
 *   Confirmation: 15M close above 06:00 4H HIGH
 *
 * Bearish setup (Turtle Soup):
 *   02:00 4H candle = reference
 *   06:00 4H candle raids above 02:00 high (short raid)
 *   06:00 candle rejects and CLOSES BACK INSIDE 02:00 range
 *   Then wait for bearish 15M MSS confirmation
 */
export function getHTFBiasFromRaid(raid: RaidEvent | null): StructureDirection {
  if (!raid) return 'neutral';
  if (raid.raidDirection === 'long') return 'bullish';
  if (raid.raidDirection === 'short' && raid.turtleSoup) return 'bearish';
  return 'neutral';
}

// ============================================================
// Floating HTF Candle Area Renderer
// Renders 4H, 1D, 1W candles in a dedicated floating panel
// on the RIGHT side of the main chart.
//
// 4H closest to main chart, 1D farther right, 1W farthest right.
// Each candle: open, high, low, close, body, wicks, bull/bear state.
// No future candles. No decorative candles.
// ============================================================

import { Candle, AppSettings } from '@/types';

export interface HTFData {
  fourH: Candle[];
  oneDay: Candle[];
  oneWeek: Candle[];
}

export interface HTFTimer {
  label: string;
  msRemaining: number;
  closesIn: string;
}

export interface HTFOpenLevel {
  label: string;
  price: number;
  color: string;
}

/**
 * Calculate the time remaining until the next candle closes.
 */
export function calculateHTFTimer(candles: Candle[], intervalMs: number, label: string): HTFTimer | null {
  if (candles.length === 0) return null;
  const lastCandle = candles[candles.length - 1];
  const nextClose = lastCandle.timestamp + intervalMs;
  const remaining = nextClose - Date.now();

  if (remaining <= 0) {
    return { label, msRemaining: 0, closesIn: 'CLOSED' };
  }

  const hours = Math.floor(remaining / (60 * 60 * 1000));
  const minutes = Math.floor((remaining % (60 * 60 * 1000)) / (60 * 1000));
  const seconds = Math.floor((remaining % (60 * 1000)) / 1000);

  let closesIn: string;
  if (hours > 0) {
    closesIn = `${hours}h ${minutes}m`;
  } else if (minutes > 0) {
    closesIn = `${minutes}m ${seconds}s`;
  } else {
    closesIn = `${seconds}s`;
  }

  return { label, msRemaining: remaining, closesIn };
}

/**
 * Get the open level (first candle's open) for an HTF.
 */
export function getHTFOpenLevel(candles: Candle[], label: string, color: string): HTFOpenLevel | null {
  if (candles.length === 0) return null;
  const lastCandle = candles[candles.length - 1];
  return { label: `${label} OPEN`, price: lastCandle.open, color };
}

/**
 * Render the HTF floating panel on a separate canvas.
 */
export function renderHTFPanel(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  htfData: HTFData,
  settings: AppSettings
) {
  const colors = {
    bg: '#0d1117',
    border: '#1a1f2e',
    text: '#6b7280',
    textBright: '#9ca3af',
    bull: '#26a69a',
    bear: '#ef5350',
    label: '#4b5563',
  };

  // Panel background
  ctx.fillStyle = colors.bg;
  ctx.fillRect(x, y, width, height);

  // Border
  ctx.strokeStyle = colors.border;
  ctx.lineWidth = 1;
  ctx.strokeRect(x, y, width, height);

  // Section layout: 4H | 1D | 1W
  const sectionWidth = width / 3;
  const sections = [
    { label: '4H', candles: htfData.fourH.slice(-settings.fourHCandleCount), color: '#3b82f6' },
    { label: '1D', candles: htfData.oneDay.slice(-settings.oneDCandleCount), color: '#f59e0b' },
    { label: '1W', candles: htfData.oneWeek.slice(-settings.oneWCandleCount), color: '#8b5cf6' },
  ];

  for (let s = 0; s < sections.length; s++) {
    const section = sections[s];
    const sx = x + s * sectionWidth;
    const sy = y + 24; // leave room for label
    const sw = sectionWidth;
    const sh = height - 30;

    // Section divider
    if (s > 0) {
      ctx.strokeStyle = colors.border;
      ctx.beginPath();
      ctx.moveTo(sx, y);
      ctx.lineTo(sx, y + height);
      ctx.stroke();
    }

    // Section label
    ctx.fillStyle = section.color;
    ctx.font = 'bold 10px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(section.label, sx + sw / 2, y + 16);

    if (section.candles.length === 0) {
      ctx.fillStyle = colors.text;
      ctx.font = '9px monospace';
      ctx.fillText('—', sx + sw / 2, sy + sh / 2);
      continue;
    }

    // Calculate price range across all candles in this section
    let minPrice = Infinity, maxPrice = -Infinity;
    for (const c of section.candles) {
      if (c.low < minPrice) minPrice = c.low;
      if (c.high > maxPrice) maxPrice = c.high;
    }
    if (minPrice === Infinity) continue;
    const padding = (maxPrice - minPrice) * 0.1;
    minPrice -= padding;
    maxPrice += padding;

    const candleAreaHeight = sh;
    const candleWidth = (sw - 8) / section.candles.length;
    const bodyWidth = Math.max(2, candleWidth * 0.6);

    for (let i = 0; i < section.candles.length; i++) {
      const candle = section.candles[i];
      const cx = sx + 4 + i * candleWidth + candleWidth / 2;
      const isBull = candle.close >= candle.open;
      const color = isBull ? colors.bull : colors.bear;

      // Wick
      const yHigh = sy + candleAreaHeight - ((candle.high - minPrice) / (maxPrice - minPrice)) * candleAreaHeight;
      const yLow = sy + candleAreaHeight - ((candle.low - minPrice) / (maxPrice - minPrice)) * candleAreaHeight;
      ctx.strokeStyle = color;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(cx, yHigh);
      ctx.lineTo(cx, yLow);
      ctx.stroke();

      // Body
      const yOpen = sy + candleAreaHeight - ((candle.open - minPrice) / (maxPrice - minPrice)) * candleAreaHeight;
      const yClose = sy + candleAreaHeight - ((candle.close - minPrice) / (maxPrice - minPrice)) * candleAreaHeight;
      const bodyTop = Math.min(yOpen, yClose);
      const bodyHeight = Math.max(1, Math.abs(yClose - yOpen));
      ctx.fillStyle = color;
      ctx.fillRect(cx - bodyWidth / 2, bodyTop, bodyWidth, bodyHeight);
    }

    // Show last close price below the section
    const lastCandle = section.candles[section.candles.length - 1];
    ctx.fillStyle = lastCandle.close >= lastCandle.open ? colors.bull : colors.bear;
    ctx.font = '9px monospace';
    ctx.textAlign = 'center';
    const priceStr = lastCandle.close > 100 ? lastCandle.close.toFixed(1) : lastCandle.close.toFixed(4);
    ctx.fillText(priceStr, sx + sw / 2, y + height - 4);
  }
}

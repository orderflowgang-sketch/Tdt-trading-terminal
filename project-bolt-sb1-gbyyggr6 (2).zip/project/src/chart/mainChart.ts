// ============================================================
// Main Chart Renderer — Canvas-based candlestick chart
// Professional dark trading terminal chart with:
//   candles, price scale, time scale, crosshair, zoom, pan
//   TDT separators, signal markers, structure overlays
// Mobile-first, efficient rendering.
// ============================================================

import { Candle, SignalResult, RaidEvent, MSSEvent, SweepEvent, FVGEvent, OBEvent, AppSettings } from '@/types';
import { getSeparatorForTimestamp, TDT_OPEN_SEPARATORS } from '@/tdt/separators';

export interface ChartOverlays {
  raids?: RaidEvent[];
  mssEvents?: MSSEvent[];
  sweeps?: SweepEvent[];
  fvgs?: FVGEvent[];
  orderBlocks?: OBEvent[];
  signal?: SignalResult | null;
  tdtSeparators?: boolean;
  tdtNodes?: boolean;
  htfOpenLevels?: { label: string; price: number; color: string }[];
}

export interface ChartRenderConfig {
  width: number;
  height: number;
  settings: AppSettings;
  timezone: string;
  overlays: ChartOverlays;
}

interface ChartLayout {
  chartLeft: number;
  chartRight: number;
  chartTop: number;
  chartBottom: number;
  priceWidth: number;
  timeHeight: number;
}

/**
 * Main chart renderer class.
 * Handles candlestick rendering, zoom, pan, crosshair, and overlays.
 */
export class ChartRenderer {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private candles: Candle[] = [];
  private config: ChartRenderConfig | null = null;

  // View state
  private visibleStart = 0;
  private visibleCount = 80;
  private panOffset = 0;
  private zoomLevel = 1;

  // Crosshair
  private crosshairX = -1;
  private crosshairY = -1;
  private showCrosshair = false;

  // Colors
  private colors = {
    bg: '#0a0e14',
    grid: '#1a1f2e',
    axis: '#2a3142',
    text: '#6b7280',
    textBright: '#9ca3af',
    bull: '#26a69a',
    bear: '#ef5350',
    wickBull: '#26a69a',
    wickBear: '#ef5350',
    separator: '#3b82f6',
    separatorLabel: '#60a5fa',
    raidLong: '#22c55e',
    raidShort: '#f97316',
    mssBull: '#10b981',
    mssBear: '#ef4444',
    signalBuy: '#22c55e',
    signalSell: '#ef4444',
    sweepBull: '#3b82f6',
    sweepBear: '#f59e0b',
    fvgBull: 'rgba(38, 166, 154, 0.1)',
    fvgBear: 'rgba(239, 83, 80, 0.1)',
    obBull: 'rgba(38, 166, 154, 0.15)',
    obBear: 'rgba(239, 83, 80, 0.15)',
    crosshair: '#4b5563',
    crosshairLabel: '#1e293b',
  };

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas 2D context not available');
    this.ctx = ctx;
  }

  setCandles(candles: Candle[]) {
    this.candles = candles;
    this.visibleStart = 0;
    this.visibleCount = Math.min(candles.length, 80);
  }

  setConfig(config: ChartRenderConfig) {
    this.config = config;
  }

  pan(deltaX: number) {
    const candleWidth = this.getCandleWidth();
    const deltaCandles = Math.round(-deltaX / candleWidth);
    this.visibleStart = Math.max(0, Math.min(
      Math.max(0, this.candles.length - this.visibleCount),
      this.visibleStart + deltaCandles
    ));
  }

  zoom(delta: number, centerX: number) {
    const oldCount = this.visibleCount;
    this.visibleCount = Math.max(20, Math.min(300, this.visibleCount + Math.round(delta)));
    // Adjust start to keep center roughly stable
    const ratio = oldCount / this.visibleCount;
    this.visibleStart = Math.max(0, Math.min(
      Math.max(0, this.candles.length - this.visibleCount),
      Math.round(this.visibleStart * ratio)
    ));
  }

  setCrosshair(x: number, y: number, show: boolean) {
    this.crosshairX = x;
    this.crosshairY = y;
    this.showCrosshair = show;
  }

  private getLayout(): ChartLayout {
    const priceWidth = 70;
    const timeHeight = 30;
    return {
      chartLeft: 8,
      chartRight: this.canvas.width - priceWidth,
      chartTop: 10,
      chartBottom: this.canvas.height - timeHeight,
      priceWidth,
      timeHeight,
    };
  }

  private getCandleWidth(): number {
    const layout = this.getLayout();
    const chartWidth = layout.chartRight - layout.chartLeft;
    return chartWidth / this.visibleCount;
  }

  private getVisibleCandles(): Candle[] {
    const start = Math.min(this.visibleStart, Math.max(0, this.candles.length - this.visibleCount));
    return this.candles.slice(start, start + this.visibleCount);
  }

  private getPriceRange(candles: Candle[]): { min: number; max: number } {
    if (candles.length === 0) return { min: 0, max: 1 };
    let min = Infinity, max = -Infinity;
    for (const c of candles) {
      if (c.low < min) min = c.low;
      if (c.high > max) max = c.high;
    }
    const padding = (max - min) * 0.05;
    return { min: min - padding, max: max + padding };
  }

  private priceToY(price: number, min: number, max: number, layout: ChartLayout): number {
    const chartHeight = layout.chartBottom - layout.chartTop;
    return layout.chartTop + chartHeight - ((price - min) / (max - min)) * chartHeight;
  }

  private yToPrice(y: number, min: number, max: number, layout: ChartLayout): number {
    const chartHeight = layout.chartBottom - layout.chartTop;
    return min + (1 - (y - layout.chartTop) / chartHeight) * (max - min);
  }

  private indexToX(index: number, layout: ChartLayout): number {
    const candleWidth = this.getCandleWidth();
    return layout.chartLeft + index * candleWidth + candleWidth / 2;
  }

  private xToIndex(x: number, layout: ChartLayout): number {
    const candleWidth = this.getCandleWidth();
    return Math.floor((x - layout.chartLeft) / candleWidth);
  }

  render() {
    const ctx = this.ctx;
    const layout = this.getLayout();
    const w = this.canvas.width;
    const h = this.canvas.height;

    // Background
    ctx.fillStyle = this.colors.bg;
    ctx.fillRect(0, 0, w, h);

    if (this.candles.length === 0) {
      ctx.fillStyle = this.colors.text;
      ctx.font = '14px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('NO MARKET DATA', w / 2, h / 2);
      return;
    }

    const visible = this.getVisibleCandles();
    const { min: priceMin, max: priceMax } = this.getPriceRange(visible);
    const candleWidth = this.getCandleWidth();
    const bodyWidth = Math.max(1, candleWidth * 0.65);

    // Grid lines
    ctx.strokeStyle = this.colors.grid;
    ctx.lineWidth = 1;
    ctx.font = '10px monospace';
    ctx.textAlign = 'left';

    // Horizontal grid (price levels)
    const priceSteps = 6;
    for (let i = 0; i <= priceSteps; i++) {
      const price = priceMin + (priceMax - priceMin) * (i / priceSteps);
      const y = this.priceToY(price, priceMin, priceMax, layout);
      ctx.beginPath();
      ctx.moveTo(layout.chartLeft, y);
      ctx.lineTo(layout.chartRight, y);
      ctx.stroke();

      // Price label
      ctx.fillStyle = this.colors.text;
      ctx.fillText(price.toFixed(price > 100 ? 1 : 5), layout.chartRight + 4, y + 3);
    }

    // Vertical grid (time)
    const timeStep = Math.max(1, Math.floor(this.visibleCount / 8));
    ctx.textAlign = 'center';
    for (let i = 0; i < visible.length; i += timeStep) {
      const x = this.indexToX(i, layout);
      if (x < layout.chartLeft || x > layout.chartRight) continue;
      ctx.strokeStyle = this.colors.grid;
      ctx.beginPath();
      ctx.moveTo(x, layout.chartTop);
      ctx.lineTo(x, layout.chartBottom);
      ctx.stroke();

      // Time label
      const date = new Date(visible[i].timestamp);
      const tz = this.config?.timezone ?? 'Africa/Johannesburg';
      try {
        const timeStr = new Intl.DateTimeFormat('en-US', {
          timeZone: tz, hour: '2-digit', minute: '2-digit', hour12: false,
        }).format(date);
        const dayStr = new Intl.DateTimeFormat('en-US', {
          timeZone: tz, day: '2-digit', month: 'short',
        }).format(date);
        ctx.fillStyle = this.colors.text;
        ctx.fillText(timeStr, x, layout.chartBottom + 14);
        ctx.fillStyle = this.colors.text;
        ctx.font = '9px monospace';
        ctx.fillText(dayStr, x, layout.chartBottom + 24);
        ctx.font = '10px monospace';
      } catch {
        ctx.fillStyle = this.colors.text;
        ctx.fillText(date.toISOString().slice(11, 16), x, layout.chartBottom + 14);
      }
    }

    // TDT Open Separators
    if (this.config?.overlays.tdtSeparators && this.config?.settings.tdtSeparatorVisibility) {
      const tz = this.config.timezone;
      for (let i = 0; i < visible.length; i++) {
        const sep = getSeparatorForTimestamp(visible[i].timestamp, tz);
        if (sep) {
          // Only draw if we haven't drawn one recently (avoid duplicates)
          const prev = i > 0 ? getSeparatorForTimestamp(visible[i - 1].timestamp, tz) : null;
          if (!prev || prev.hour !== sep.hour) {
            const x = this.indexToX(i, layout);
            ctx.strokeStyle = this.colors.separator;
            ctx.lineWidth = 1;
            ctx.setLineDash([4, 4]);
            ctx.beginPath();
            ctx.moveTo(x, layout.chartTop);
            ctx.lineTo(x, layout.chartBottom);
            ctx.stroke();
            ctx.setLineDash([]);

            // Label
            ctx.fillStyle = this.colors.separatorLabel;
            ctx.font = '9px monospace';
            ctx.textAlign = 'left';
            ctx.fillText(sep.fullLabel, x + 2, layout.chartTop + 12);
          }
        }
      }
    }

    // FVG overlays
    if (this.config?.overlays.fvgs && this.config?.settings.fvgVisibility) {
      for (const fvg of this.config.overlays.fvgs) {
        const startIdx = visible.findIndex((c) => c.timestamp >= fvg.startTimestamp);
        if (startIdx < 0) continue;
        const x = this.indexToX(startIdx, layout);
        const yTop = this.priceToY(fvg.top, priceMin, priceMax, layout);
        const yBottom = this.priceToY(fvg.bottom, priceMin, priceMax, layout);
        ctx.fillStyle = fvg.direction === 'bullish' ? this.colors.fvgBull : this.colors.fvgBear;
        ctx.fillRect(x, yTop, layout.chartRight - x, yBottom - yTop);
      }
    }

    // Order Block overlays
    if (this.config?.overlays.orderBlocks && this.config?.settings.obVisibility) {
      for (const ob of this.config.overlays.orderBlocks) {
        const idx = visible.findIndex((c) => c.timestamp >= ob.timestamp);
        if (idx < 0) continue;
        const x = this.indexToX(idx, layout);
        const yTop = this.priceToY(ob.top, priceMin, priceMax, layout);
        const yBottom = this.priceToY(ob.bottom, priceMin, priceMax, layout);
        ctx.fillStyle = ob.direction === 'bullish' ? this.colors.obBull : this.colors.obBear;
        ctx.fillRect(x, yTop, layout.chartRight - x, yBottom - yTop);
        ctx.strokeStyle = ob.direction === 'bullish' ? this.colors.bull : this.colors.bear;
        ctx.lineWidth = 0.5;
        ctx.strokeRect(x, yTop, layout.chartRight - x, yBottom - yTop);
      }
    }

    // HTF open levels
    if (this.config?.overlays.htfOpenLevels && this.config?.settings.htfVisibility) {
      for (const level of this.config.overlays.htfOpenLevels) {
        const y = this.priceToY(level.price, priceMin, priceMax, layout);
        if (y < layout.chartTop || y > layout.chartBottom) continue;
        ctx.strokeStyle = level.color;
        ctx.lineWidth = 1;
        ctx.setLineDash([2, 4]);
        ctx.beginPath();
        ctx.moveTo(layout.chartLeft, y);
        ctx.lineTo(layout.chartRight, y);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.fillStyle = level.color;
        ctx.font = '9px monospace';
        ctx.textAlign = 'left';
        ctx.fillText(level.label, layout.chartLeft + 4, y - 3);
      }
    }

    // Sweeps
    if (this.config?.overlays.sweeps && this.config?.settings.sweepVisibility) {
      for (const sweep of this.config.overlays.sweeps) {
        const idx = visible.findIndex((c) => c.timestamp === sweep.timestamp);
        if (idx < 0) continue;
        const x = this.indexToX(idx, layout);
        const y = this.priceToY(sweep.level, priceMin, priceMax, layout);
        ctx.strokeStyle = sweep.direction === 'bullish' ? this.colors.sweepBull : this.colors.sweepBear;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(x, y, 4, 0, Math.PI * 2);
        ctx.stroke();
      }
    }

    // Candles (drawn on top of separators, behind markers)
    for (let i = 0; i < visible.length; i++) {
      const candle = visible[i];
      const x = this.indexToX(i, layout);
      const isBull = candle.close >= candle.open;
      const color = isBull ? this.colors.bull : this.colors.bear;
      const wickColor = isBull ? this.colors.wickBull : this.colors.wickBear;

      // Wick
      const yHigh = this.priceToY(candle.high, priceMin, priceMax, layout);
      const yLow = this.priceToY(candle.low, priceMin, priceMax, layout);
      ctx.strokeStyle = wickColor;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(x, yHigh);
      ctx.lineTo(x, yLow);
      ctx.stroke();

      // Body
      const yOpen = this.priceToY(candle.open, priceMin, priceMax, layout);
      const yClose = this.priceToY(candle.close, priceMin, priceMax, layout);
      const bodyTop = Math.min(yOpen, yClose);
      const bodyHeight = Math.max(1, Math.abs(yClose - yOpen));
      ctx.fillStyle = color;
      ctx.fillRect(x - bodyWidth / 2, bodyTop, bodyWidth, bodyHeight);
    }

    // 4H Raid markers
    if (this.config?.overlays.raids) {
      for (const raid of this.config.overlays.raids) {
        const refIdx = visible.findIndex((c) => c.timestamp === raid.referenceCandle.timestamp);
        const raidIdx = visible.findIndex((c) => c.timestamp === raid.raidCandle.timestamp);

        if (refIdx >= 0) {
          const x = this.indexToX(refIdx, layout);
          // Reference range lines
          const yHigh = this.priceToY(raid.referenceCandle.high, priceMin, priceMax, layout);
          const yLow = this.priceToY(raid.referenceCandle.low, priceMin, priceMax, layout);
          ctx.strokeStyle = 'rgba(100, 116, 139, 0.5)';
          ctx.lineWidth = 1;
          ctx.setLineDash([3, 3]);
          ctx.beginPath();
          ctx.moveTo(x, yHigh);
          ctx.lineTo(layout.chartRight, yHigh);
          ctx.moveTo(x, yLow);
          ctx.lineTo(layout.chartRight, yLow);
          ctx.stroke();
          ctx.setLineDash([]);
        }

        if (raidIdx >= 0) {
          const x = this.indexToX(raidIdx, layout);
          const yRaid = this.priceToY(raid.raidPrice, priceMin, priceMax, layout);
          ctx.strokeStyle = raid.raidDirection === 'long' ? this.colors.raidLong : this.colors.raidShort;
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(x, yRaid, 5, 0, Math.PI * 2);
          ctx.stroke();

          // Label
          ctx.fillStyle = raid.raidDirection === 'long' ? this.colors.raidLong : this.colors.raidShort;
          ctx.font = '8px monospace';
          ctx.textAlign = 'center';
          ctx.fillText(raid.raidDirection === 'long' ? 'LONG RAID' : 'SHORT RAID', x, yRaid - 8);
        }
      }
    }

    // MSS markers
    if (this.config?.overlays.mssEvents && this.config?.settings.mssVisibility) {
      for (const mss of this.config.overlays.mssEvents) {
        const idx = visible.findIndex((c) => c.timestamp === mss.confirmationTimestamp);
        if (idx < 0) continue;
        const x = this.indexToX(idx, layout);
        const y = this.priceToY(mss.confirmationPrice, priceMin, priceMax, layout);

        // Break level line
        const yBreak = this.priceToY(mss.breakLevel, priceMin, priceMax, layout);
        ctx.strokeStyle = mss.direction === 'bullish' ? this.colors.mssBull : this.colors.mssBear;
        ctx.lineWidth = 1.5;
        ctx.setLineDash([5, 3]);
        ctx.beginPath();
        ctx.moveTo(layout.chartLeft, yBreak);
        ctx.lineTo(x, yBreak);
        ctx.stroke();
        ctx.setLineDash([]);

        // MSS marker
        ctx.fillStyle = mss.direction === 'bullish' ? this.colors.mssBull : this.colors.mssBear;
        ctx.font = 'bold 9px monospace';
        ctx.textAlign = 'center';
        ctx.fillText('MSS', x, y + (mss.direction === 'bullish' ? -10 : 16));
      }
    }

    // Signal markers (BUY/SELL)
    if (this.config?.overlays.signal && this.config?.settings.signalVisibility) {
      const sig = this.config.overlays.signal;
      if (sig.triggerTime && sig.triggerPrice) {
        const idx = visible.findIndex((c) => c.timestamp === sig.triggerTime);
        if (idx >= 0) {
          const x = this.indexToX(idx, layout);
          const y = this.priceToY(sig.triggerPrice, priceMin, priceMax, layout);
          const color = sig.state === 'BUY' ? this.colors.signalBuy : this.colors.signalSell;

          // Arrow
          ctx.fillStyle = color;
          ctx.beginPath();
          if (sig.state === 'BUY') {
            ctx.moveTo(x, y + 15);
            ctx.lineTo(x - 6, y + 25);
            ctx.lineTo(x + 6, y + 25);
          } else {
            ctx.moveTo(x, y - 15);
            ctx.lineTo(x - 6, y - 25);
            ctx.lineTo(x + 6, y - 25);
          }
          ctx.closePath();
          ctx.fill();

          // Label
          ctx.font = 'bold 11px monospace';
          ctx.textAlign = 'center';
          ctx.fillText(sig.state, x, sig.state === 'BUY' ? y + 38 : y - 30);
        }
      }
    }

    // Crosshair
    if (this.showCrosshair && this.crosshairX >= 0 && this.crosshairY >= 0) {
      ctx.strokeStyle = this.colors.crosshair;
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      ctx.moveTo(layout.chartLeft, this.crosshairY);
      ctx.lineTo(layout.chartRight, this.crosshairY);
      ctx.moveTo(this.crosshairX, layout.chartTop);
      ctx.lineTo(this.crosshairX, layout.chartBottom);
      ctx.stroke();
      ctx.setLineDash([]);

      // Price label on crosshair
      const price = this.yToPrice(this.crosshairY, priceMin, priceMax, layout);
      ctx.fillStyle = this.colors.crosshairLabel;
      ctx.fillRect(layout.chartRight, this.crosshairY - 8, layout.priceWidth, 16);
      ctx.fillStyle = '#fff';
      ctx.font = '10px monospace';
      ctx.textAlign = 'left';
      ctx.fillText(price.toFixed(price > 100 ? 1 : 5), layout.chartRight + 4, this.crosshairY + 3);

      // Time label on crosshair
      const idx = this.xToIndex(this.crosshairX, layout);
      if (idx >= 0 && idx < visible.length) {
        const date = new Date(visible[idx].timestamp);
        const tz = this.config?.timezone ?? 'Africa/Johannesburg';
        try {
          const timeStr = new Intl.DateTimeFormat('en-US', {
            timeZone: tz, hour: '2-digit', minute: '2-digit', day: '2-digit', month: 'short', hour12: false,
          }).format(date);
          ctx.fillStyle = this.colors.crosshairLabel;
          ctx.fillRect(this.crosshairX - 40, layout.chartBottom, 80, layout.timeHeight);
          ctx.fillStyle = '#fff';
          ctx.textAlign = 'center';
          ctx.fillText(timeStr, this.crosshairX, layout.chartBottom + 18);
        } catch {
          // skip
        }
      }
    }

    // Last price line
    if (visible.length > 0) {
      const lastCandle = visible[visible.length - 1];
      const y = this.priceToY(lastCandle.close, priceMin, priceMax, layout);
      const isBull = lastCandle.close >= lastCandle.open;
      ctx.strokeStyle = isBull ? this.colors.bull : this.colors.bear;
      ctx.lineWidth = 1;
      ctx.setLineDash([2, 2]);
      ctx.beginPath();
      ctx.moveTo(layout.chartLeft, y);
      ctx.lineTo(layout.chartRight, y);
      ctx.stroke();
      ctx.setLineDash([]);

      // Current price label
      ctx.fillStyle = isBull ? this.colors.bull : this.colors.bear;
      ctx.fillRect(layout.chartRight, y - 8, layout.priceWidth, 16);
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 10px monospace';
      ctx.textAlign = 'left';
      ctx.fillText(lastCandle.close.toFixed(lastCandle.close > 100 ? 1 : 5), layout.chartRight + 4, y + 3);
    }
  }

  /**
   * Get the candle at a screen x coordinate (for tooltips/data lookup).
   */
  getCandleAtX(x: number): Candle | null {
    const layout = this.getLayout();
    const idx = this.xToIndex(x, layout);
    const visible = this.getVisibleCandles();
    if (idx >= 0 && idx < visible.length) {
      return visible[idx];
    }
    return null;
  }

  /**
   * Reset view to show the most recent candles.
   */
  resetView() {
    this.visibleStart = Math.max(0, this.candles.length - this.visibleCount);
  }
}

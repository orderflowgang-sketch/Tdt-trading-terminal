// ============================================================
// TDT TRADING TERMINAL — Core Type Definitions
// ============================================================

// ---- Market Data ----

export type Timeframe = '1min' | '5min' | '15min' | '30min' | '1h' | '4h' | '1day' | '1week';

export interface Candle {
  timestamp: number; // Unix ms (start of candle)
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

export interface Instrument {
  symbol: string;
  label: string;
  assetClass: 'crypto' | 'metal' | 'forex' | 'index';
}

export const INSTRUMENTS: Instrument[] = [
  { symbol: 'BTC/USD', label: 'Bitcoin', assetClass: 'crypto' },
  { symbol: 'ETH/USD', label: 'Ethereum', assetClass: 'crypto' },
  { symbol: 'SOL/USD', label: 'Solana', assetClass: 'crypto' },
  { symbol: 'BNB/USD', label: 'BNB', assetClass: 'crypto' },
  { symbol: 'XRP/USD', label: 'Ripple', assetClass: 'crypto' },
  { symbol: 'XAU/USD', label: 'Gold (via BTC)', assetClass: 'metal' },
];

export const TIMEFRAMES: { value: Timeframe; label: string }[] = [
  { value: '1min', label: '1m' },
  { value: '5min', label: '5m' },
  { value: '15min', label: '15m' },
  { value: '30min', label: '30m' },
  { value: '1h', label: '1H' },
  { value: '4h', label: '4H' },
  { value: '1day', label: '1D' },
  { value: '1week', label: '1W' },
];

// ---- TDT ----

export interface TDTDayInfo {
  date: Date;
  dayOfMonth: number;
  digitalRoot: number;
  isExpansion: boolean;
  rootType: 'expansion' | 'non-expansion';
  model1Event: Model1CalendarEvent | null;
  ratio: string | null;
  status: string;
}

export interface Model1CalendarEvent {
  root: number;
  ratio: string; // e.g. "1:6"
  node: number;
  sastTime: string; // e.g. "07:00"
  type: 'Model 1' | 'Continuation' | 'Early Expansion';
  label: string;
}

export interface TDTNode {
  node: number; // 1-24
  sastHour: number; // 0-23
  label: string; // e.g. "02:00"
  isSeparator: boolean;
}

// ---- Structure ----

export type StructureDirection = 'bullish' | 'bearish' | 'neutral';

export interface RaidEvent {
  referenceCandle: Candle;
  raidCandle: Candle;
  raidedLevel: 'high' | 'low';
  raidDirection: 'long' | 'short'; // long = raided low (bullish), short = raided high (bearish)
  raidTimestamp: number;
  raidPrice: number;
  turtleSoup: boolean; // did the raid candle close back inside?
}

export interface MSSEvent {
  direction: StructureDirection;
  breakLevel: number;
  confirmationCandle: Candle;
  confirmationTimestamp: number;
  confirmationPrice: number;
  structureState: string;
}

export interface SweepEvent {
  direction: 'bullish' | 'bearish';
  level: number;
  candle: Candle;
  timestamp: number;
}

export interface FVGEvent {
  direction: 'bullish' | 'bearish';
  top: number;
  bottom: number;
  startTimestamp: number;
  endTimestamp: number;
}

export interface OBEvent {
  direction: 'bullish' | 'bearish';
  top: number;
  bottom: number;
  timestamp: number;
}

// ---- Signals ----

export type SignalState = 'BUY' | 'SELL' | 'WAITING_FOR_CONFIRMATION' | 'NO_SIGNAL';

export interface SignalResult {
  state: SignalState;
  date: Date;
  root: number;
  ratio: string | null;
  node: number | null;
  eventTime: string | null;
  htfBias: StructureDirection;
  fourHRaid: 'CONFIRMED' | 'TURTLE SOUP' | 'NONE' | 'WAITING';
  fifteenMSss: StructureDirection;
  triggerTime: number | null;
  triggerPrice: number | null;
  explanation: string;
}

// ---- Directional Bias ----

export type BiasState = 'bullish' | 'bearish' | 'neutral' | 'expansion';

export interface BiasResult {
  state: BiasState;
  sweepDirection: 'sell_side' | 'buy_side' | 'none';
  sweepTime: number | null;
  sweepPrice: number | null;
  mssConfirmed: boolean;
  mssDirection: StructureDirection;
  currentNode: number;
  preNode12: boolean;
  postNode20: boolean;
  htfOpen: number | null;
  htfOpenTime: number | null;
  explanation: string;
}

// ---- Fractal ----

export interface FractalMatch {
  date: Date;
  similarity: number; // 0-100
  direction: StructureDirection;
  pathCorrelation: number;
  swingCorrelation: number;
  volatilityMatch: number;
}

// ---- Settings ----

export interface AppSettings {
  timezone: string;
  instrument: string;
  timeframe: Timeframe;
  theme: 'dark' | 'light';
  tdtNodeVisibility: boolean;
  tdtSeparatorVisibility: boolean;
  htfVisibility: boolean;
  fourHCandleCount: number;
  oneDCandleCount: number;
  oneWCandleCount: number;
  htfPanelWidth: number;
  fvgVisibility: boolean;
  obVisibility: boolean;
  sweepVisibility: boolean;
  mssVisibility: boolean;
  signalVisibility: boolean;
  notifications: boolean;
}

export const DEFAULT_SETTINGS: AppSettings = {
  timezone: 'Africa/Johannesburg',
  instrument: 'BTC/USD',
  timeframe: '15min',
  theme: 'dark',
  tdtNodeVisibility: true,
  tdtSeparatorVisibility: true,
  htfVisibility: true,
  fourHCandleCount: 4,
  oneDCandleCount: 3,
  oneWCandleCount: 3,
  htfPanelWidth: 120,
  fvgVisibility: true,
  obVisibility: true,
  sweepVisibility: true,
  mssVisibility: true,
  signalVisibility: true,
  notifications: false,
};

// ============================================================
// Market Data Client (Binance Public API)
// Frontend client that calls the Binance edge function proxy.
// No API key needed — Binance public endpoints are free and unlimited.
// ============================================================

import { Candle, Timeframe } from '@/types';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;
const FUNCTION_URL = `${SUPABASE_URL}/functions/v1/market-data`;

const headers: Record<string, string> = {
  Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
  'Content-Type': 'application/json',
};

// Client-side cache for candle data
const candleCache = new Map<string, { data: Candle[]; timestamp: number }>();
const CACHE_TTL = 30 * 1000;          // 30s for real-time
const CACHE_TTL_HISTORICAL = 5 * 60 * 1000; // 5min for historical

function getCached(key: string): Candle[] | null {
  const entry = candleCache.get(key);
  if (!entry) return null;
  const ttl = key.startsWith('hist_') ? CACHE_TTL_HISTORICAL : CACHE_TTL;
  if (Date.now() - entry.timestamp > ttl) {
    candleCache.delete(key);
    return null;
  }
  return entry.data;
}

function setCached(key: string, data: Candle[]) {
  candleCache.set(key, { data, timestamp: Date.now() });
}

/**
 * The edge function returns already-parsed candle objects from Binance klines.
 * Binance returns chronological order (oldest first) which matches our internal format.
 */
function parseCandleResponse(data: unknown): Candle[] {
  if (!Array.isArray(data)) return [];
  return data.map((c: Record<string, unknown>) => ({
    timestamp: Number(c.timestamp),
    open: Number(c.open),
    high: Number(c.high),
    low: Number(c.low),
    close: Number(c.close),
    volume: c.volume !== undefined ? Number(c.volume) : undefined,
  }));
}

/**
 * Fetch candlestick data for a symbol + timeframe.
 */
export async function fetchCandles(
  symbol: string,
  interval: Timeframe,
  outputsize: number = 200
): Promise<Candle[]> {
  const cacheKey = `candles_${symbol}_${interval}_${outputsize}`;
  const cached = getCached(cacheKey);
  if (cached) return cached;

  const params = new URLSearchParams({
    action: 'klines',
    symbol,
    interval,
    outputsize: outputsize.toString(),
  });

  const response = await fetch(`${FUNCTION_URL}?${params.toString()}`, { headers });
  if (!response.ok) {
    const errBody = await response.json().catch(() => ({ error: `Market data request failed (${response.status})` }));
    throw new Error(errBody.error || `Market data request failed (${response.status})`);
  }

  const data = await response.json();
  if (data.error) throw new Error(data.error);

  const candles = parseCandleResponse(data);
  setCached(cacheKey, candles);
  return candles;
}

/**
 * Fetch historical candles for a specific date range.
 * start/end in ISO format (YYYY-MM-DD).
 */
export async function fetchHistoricalCandles(
  symbol: string,
  interval: Timeframe,
  startDate: string,
  endDate: string,
  outputsize: number = 500
): Promise<Candle[]> {
  const cacheKey = `hist_${symbol}_${interval}_${startDate}_${endDate}`;
  const cached = getCached(cacheKey);
  if (cached) return cached;

  const params = new URLSearchParams({
    action: 'klines',
    symbol,
    interval,
    outputsize: outputsize.toString(),
    start: startDate,
    end: endDate,
  });

  const response = await fetch(`${FUNCTION_URL}?${params.toString()}`, { headers });
  if (!response.ok) {
    const errBody = await response.json().catch(() => ({ error: `Historical data request failed (${response.status})` }));
    throw new Error(errBody.error || `Historical data request failed (${response.status})`);
  }

  const data = await response.json();
  if (data.error) throw new Error(data.error);

  const candles = parseCandleResponse(data);
  setCached(cacheKey, candles);
  return candles;
}

/**
 * Fetch the current real-time price for a symbol.
 */
export async function fetchPrice(symbol: string): Promise<number | null> {
  const params = new URLSearchParams({
    action: 'price',
    symbol,
  });

  try {
    const response = await fetch(`${FUNCTION_URL}?${params.toString()}`, { headers });
    if (!response.ok) return null;
    const data = await response.json();
    if (data.error) return null;
    return Number(data.price) || null;
  } catch {
    return null;
  }
}

/**
 * Fetch a real-time quote (includes OHLC of current 24hr period).
 */
export async function fetchQuote(symbol: string): Promise<{
  open: number;
  high: number;
  low: number;
  close: number;
  timestamp: number;
} | null> {
  const params = new URLSearchParams({
    action: 'quote',
    symbol,
  });

  try {
    const response = await fetch(`${FUNCTION_URL}?${params.toString()}`, { headers });
    if (!response.ok) return null;
    const data = await response.json();
    if (data.error) return null;
    return {
      open: Number(data.open),
      high: Number(data.high),
      low: Number(data.low),
      close: Number(data.close),
      timestamp: Number(data.timestamp),
    };
  } catch {
    return null;
  }
}

/**
 * Fetch multiple timeframes at once for HTF analysis.
 */
export async function fetchMultiTimeframe(
  symbol: string,
  outputsize: number = 100
): Promise<{
  '15m': Candle[];
  '4h': Candle[];
  '1day': Candle[];
  '1week': Candle[];
}> {
  const [m15, h4, d1, w1] = await Promise.all([
    fetchCandles(symbol, '15min', outputsize),
    fetchCandles(symbol, '4h', Math.max(outputsize, 50)),
    fetchCandles(symbol, '1day', Math.max(outputsize, 50)),
    fetchCandles(symbol, '1week', 50),
  ]);

  return { '15m': m15, '4h': h4, '1day': d1, '1week': w1 };
}

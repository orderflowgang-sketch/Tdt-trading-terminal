// ============================================================
// Fractal Similarity Engine
// Compares Model 1 setups across history to find structurally
// similar patterns. This is NOT probability. NOT win-rate prediction.
//
// Features used:
//   candle direction, HH/HL/LH/LL, swing points, displacement,
//   retracement depth, range expansion/compression,
//   wick/body structure, volatility, normalized price path, MAE, MFE
//
// Default comparison window:
//   2 hours before event → 4 hours after event
//   15M: 8 candles before, 16 candles after
// ============================================================

import { Candle, FractalMatch, StructureDirection } from '@/types';
import { findSwings, SwingPoint } from '@/structure/mss';

const CANDLES_BEFORE = 8; // 2 hours of 15M candles
const CANDLES_AFTER = 16; // 4 hours of 15M candles
const WINDOW_SIZE = CANDLES_BEFORE + CANDLES_AFTER; // 24 candles

/**
 * Extract a window of candles around an event timestamp.
 * Returns CANDLES_BEFORE candles before + CANDLES_AFTER candles after.
 */
export function extractEventWindow(
  candles: Candle[],
  eventTimestamp: number
): Candle[] | null {
  // Find the candle closest to the event timestamp
  let eventIndex = -1;
  for (let i = 0; i < candles.length; i++) {
    if (candles[i].timestamp <= eventTimestamp) {
      eventIndex = i;
    } else {
      break;
    }
  }

  if (eventIndex < 0) return null;

  const start = eventIndex - CANDLES_BEFORE;
  const end = eventIndex + CANDLES_AFTER;

  if (start < 0 || end >= candles.length) return null;

  return candles.slice(start, end + 1);
}

/**
 * Normalize a price path to 0-1 range.
 * This removes absolute price levels and focuses on the shape.
 */
export function normalizePath(candles: Candle[]): number[] {
  const prices = candles.map((c) => c.close);
  const min = Math.min(...prices);
  const max = Math.max(...prices);
  const range = max - min;

  if (range === 0) return prices.map(() => 0.5);

  return prices.map((p) => (p - min) / range);
}

/**
 * Extract structural features from a candle window.
 */
export interface FractalFeatures {
  path: number[]; // normalized close prices
  swingPoints: SwingPoint[];
  avgVolatility: number; // average range as % of price
  avgBodyRatio: number; // average body/(high-low) ratio
  avgWickRatio: number; // average wick/(high-low) ratio
  displacement: number; // max single-candle displacement
  retracementDepth: number; // max retracement after the event
  rangeExpansion: number; // ratio of post-event range to pre-event range
  mae: number; // maximum adverse excursion
  mfe: number; // maximum favorable excursion
  direction: StructureDirection;
  hhCount: number; // higher highs
  hlCount: number; // higher lows
  lhCount: number; // lower highs
  llCount: number; // lower lows
}

export function extractFeatures(candles: Candle[], eventIndex: number = CANDLES_BEFORE): FractalFeatures {
  const path = normalizePath(candles);

  const swings = findSwings(candles, 2);

  // Volatility: average (high - low) / close
  const avgVolatility = candles.reduce((sum, c) => sum + (c.high - c.low) / c.close, 0) / candles.length;

  // Body and wick ratios
  const bodyRatios = candles.map((c) => {
    const range = c.high - c.low;
    return range > 0 ? Math.abs(c.close - c.open) / range : 0;
  });
  const avgBodyRatio = bodyRatios.reduce((a, b) => a + b, 0) / bodyRatios.length;
  const avgWickRatio = 1 - avgBodyRatio;

  // Displacement: max single-candle range
  const displacement = Math.max(...candles.map((c) => (c.high - c.low) / c.close));

  // Retracement depth: max retracement after event
  const postEvent = candles.slice(eventIndex);
  const postHigh = Math.max(...postEvent.map((c) => c.high));
  const postLow = Math.min(...postEvent.map((c) => c.low));
  const eventClose = candles[eventIndex].close;
  const retracementDepth = eventClose > 0 ? (postHigh - postLow) / eventClose : 0;

  // Range expansion: post-event range / pre-event range
  const preEvent = candles.slice(0, eventIndex);
  const preRange = Math.max(...preEvent.map((c) => c.high)) - Math.min(...preEvent.map((c) => c.low));
  const postRange = postHigh - postLow;
  const rangeExpansion = preRange > 0 ? postRange / preRange : 1;

  // MAE/MFE relative to event close
  const mae = Math.abs(eventClose - postLow) / eventClose;
  const mfe = Math.abs(postHigh - eventClose) / eventClose;

  // Direction from close comparison
  const direction: StructureDirection = candles[candles.length - 1].close > candles[0].close ? 'bullish' : 'bearish';

  // Count HH, HL, LH, LL from swings
  let hhCount = 0, hlCount = 0, lhCount = 0, llCount = 0;
  for (let i = 1; i < swings.length; i++) {
    if (swings[i].type === 'high') {
      if (swings[i].price > swings[i - 1].price) hhCount++;
      else lhCount++;
    } else {
      if (swings[i].price > swings[i - 1].price) hlCount++;
      else llCount++;
    }
  }

  return {
    path,
    swingPoints: swings,
    avgVolatility,
    avgBodyRatio,
    avgWickRatio,
    displacement,
    retracementDepth,
    rangeExpansion,
    mae,
    mfe,
    direction,
    hhCount,
    hlCount,
    lhCount,
    llCount,
  };
}

/**
 * Calculate Pearson correlation between two arrays.
 */
function correlation(a: number[], b: number[]): number {
  if (a.length !== b.length || a.length === 0) return 0;
  const n = a.length;
  const meanA = a.reduce((s, x) => s + x, 0) / n;
  const meanB = b.reduce((s, x) => s + x, 0) / n;
  let num = 0, denA = 0, denB = 0;
  for (let i = 0; i < n; i++) {
    const da = a[i] - meanA;
    const db = b[i] - meanB;
    num += da * db;
    denA += da * da;
    denB += db * db;
  }
  const den = Math.sqrt(denA * denB);
  return den === 0 ? 0 : num / den;
}

/**
 * Compare two sets of features and return a similarity score 0-100.
 */
export function compareFeatures(a: FractalFeatures, b: FractalFeatures): {
  similarity: number;
  pathCorrelation: number;
  swingCorrelation: number;
  volatilityMatch: number;
} {
  // Path correlation (weighted heavily)
  const pathCorrelation = Math.abs(correlation(a.path, b.path));

  // Swing structure similarity
  const swingCorrelation = Math.abs(
    (a.hhCount - a.lhCount) / Math.max(1, a.hhCount + a.lhCount) -
    (b.hhCount - b.lhCount) / Math.max(1, b.hhCount + b.lhCount)
  ) > 0
    ? 1 - Math.min(1, Math.abs(
        (a.hhCount - a.lhCount) / Math.max(1, a.hhCount + a.lhCount) -
        (b.hhCount - b.lhCount) / Math.max(1, b.hhCount + b.lhCount)
      ))
    : 1;

  // Volatility match (closer = higher)
  const volDiff = Math.abs(a.avgVolatility - b.avgVolatility) / Math.max(a.avgVolatility, b.avgVolatility, 0.0001);
  const volatilityMatch = Math.max(0, 1 - volDiff);

  // Body/wick ratio match
  const bodyMatch = 1 - Math.min(1, Math.abs(a.avgBodyRatio - b.avgBodyRatio));

  // Range expansion match
  const expansionMatch = 1 - Math.min(1, Math.abs(a.rangeExpansion - b.rangeExpansion) / Math.max(a.rangeExpansion, b.rangeExpansion, 0.0001));

  // Retracement match
  const retracementMatch = 1 - Math.min(1, Math.abs(a.retracementDepth - b.retracementDepth) / Math.max(a.retracementDepth, b.retracementDepth, 0.0001));

  // Direction match
  const directionMatch = a.direction === b.direction ? 1 : 0.3;

  // Weighted similarity score
  const similarity = (
    pathCorrelation * 30 +
    swingCorrelation * 15 +
    volatilityMatch * 15 +
    bodyMatch * 10 +
    expansionMatch * 10 +
    retracementMatch * 10 +
    directionMatch * 10
  );

  return {
    similarity: Math.round(Math.min(100, Math.max(0, similarity))),
    pathCorrelation: Math.round(pathCorrelation * 100),
    swingCorrelation: Math.round(swingCorrelation * 100),
    volatilityMatch: Math.round(volatilityMatch * 100),
  };
}

/**
 * Find the top N fractal matches for a reference event window.
 * Scans through historical candles, extracting windows around each
 * similar event timestamp, and compares features.
 *
 * @param referenceCandles The reference event window (24 candles)
 * @param historicalCandles Full historical candle array to scan
 * @param eventTimestamps Array of timestamps to check (e.g., previous Model 1 events)
 * @param topN Number of top matches to return (5 or 10)
 */
export function findFractalMatches(
  referenceCandles: Candle[],
  historicalCandles: Candle[],
  eventTimestamps: number[],
  topN: number = 5
): FractalMatch[] {
  const referenceFeatures = extractFeatures(referenceCandles);
  const matches: FractalMatch[] = [];

  for (const ts of eventTimestamps) {
    const window = extractEventWindow(historicalCandles, ts);
    if (!window) continue;

    const features = extractFeatures(window);
    const comparison = compareFeatures(referenceFeatures, features);

    // Find the date for this timestamp
    const date = new Date(ts);

    matches.push({
      date,
      similarity: comparison.similarity,
      direction: features.direction,
      pathCorrelation: comparison.pathCorrelation,
      swingCorrelation: comparison.swingCorrelation,
      volatilityMatch: comparison.volatilityMatch,
    });
  }

  // Sort by similarity descending, take top N
  matches.sort((a, b) => b.similarity - a.similarity);
  return matches.slice(0, topN);
}

/*
# Create app_secrets table for storing third-party API keys

1. New Tables
- `app_secrets`
  - `key` (text, primary key) — the secret name, e.g. 'TWELVE_DATA_API_KEY'
  - `value` (text, not null) — the secret value
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

2. Security
- Enable RLS on `app_secrets`.
- NO policies for anon or authenticated — the table is only accessible
  via the service role key (used by edge functions).
- This ensures API keys are never readable from the frontend.

3. Important notes
- The edge function uses SUPABASE_SERVICE_ROLE_KEY to read from this table.
- The anon key client (frontend) cannot read this table at all.
- API keys stored here are server-side only.
*/

CREATE TABLE IF NOT EXISTS app_secrets (
  key text PRIMARY KEY,
  value text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE app_secrets ENABLE ROW LEVEL SECURITY;

-- No policies created — table is locked to anon and authenticated roles.
-- Only the service role (used by edge functions) can read/write.
// ============================================================
// Binance Public API Edge Function
// Server-side market data proxy for Binance's free public API.
// No API key required. No rate limits on public klines endpoints.
// Returns real OHLCV candlestick data.
// ============================================================

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

const API_BASE = 'https://api.binance.com/api/v3';

/**
 * Map our internal instrument symbols to Binance trading pairs.
 * Binance is a crypto exchange — non-crypto instruments are mapped
 * to their closest crypto equivalent.
 */
const SYMBOL_MAP: Record<string, string> = {
  'BTC/USD': 'BTCUSDT',
  'BTCUSDT': 'BTCUSDT',
  'ETH/USD': 'ETHUSDT',
  'ETHUSDT': 'ETHUSDT',
  'SOL/USD': 'SOLUSDT',
  'SOLUSDT': 'SOLUSDT',
  'BNB/USD': 'BNBUSDT',
  'BNBUSDT': 'BNBUSDT',
  'XRP/USD': 'XRPUSDT',
  'XRPUSDT': 'XRPUSDT',
  'XAU/USD': 'BTCUSDT',   // Gold → BTC proxy (Binance has no metals)
};

/**
 * Map our internal timeframe strings to Binance interval strings.
 */
const INTERVAL_MAP: Record<string, string> = {
  '1min': '1m',
  '5min': '5m',
  '15min': '15m',
  '30min': '30m',
  '1h': '1h',
  '4h': '4h',
  '1day': '1d',
  '1week': '1w',
};

interface CacheEntry {
  data: unknown;
  timestamp: number;
}

// In-function cache
const cache = new Map<string, CacheEntry>();
const CACHE_TTL = 15 * 1000;      // 15s for real-time
const CACHE_TTL_HISTORICAL = 5 * 60 * 1000; // 5min for historical

function getCached(key: string): CacheEntry | null {
  const entry = cache.get(key);
  if (!entry) return null;
  const ttl = key.startsWith('hist_') ? CACHE_TTL_HISTORICAL : CACHE_TTL;
  if (Date.now() - entry.timestamp > ttl) {
    cache.delete(key);
    return null;
  }
  return entry;
}

function setCached(key: string, data: unknown) {
  cache.set(key, { data, timestamp: Date.now() });
}

/**
 * Convert a Binance kline array into our normalized candle object.
 * Binance returns arrays in this order:
 * [openTime, open, high, low, close, volume, closeTime, quoteVolume, trades, ...]
 */
function parseKlines(klines: unknown[][]): Array<{
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}> {
  return klines.map((k) => ({
    timestamp: Number(k[0]),
    open: parseFloat(k[1] as string),
    high: parseFloat(k[2] as string),
    low: parseFloat(k[3] as string),
    close: parseFloat(k[4] as string),
    volume: parseFloat(k[5] as string),
  }));
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const params = url.searchParams;

    const action = params.get('action') || 'klines';

    // ---- KLINES (candlestick time series) ----
    if (action === 'klines' || action === 'time_series') {
      const symbol = params.get('symbol') ?? 'BTC/USD';
      const interval = params.get('interval') || '15min';
      const limit = parseInt(params.get('outputsize') || params.get('limit') || '200', 10);
      const startTime = params.get('start') ? Date.parse(params.get('start')!) : null;
      const endTime = params.get('end') ? Date.parse(params.get('end')!) : null;

      const binanceSymbol = SYMBOL_MAP[symbol] ?? 'BTCUSDT';
      const binanceInterval = INTERVAL_MAP[interval] ?? '15m';

      const cacheKey = `klines_${binanceSymbol}_${binanceInterval}_${limit}_${startTime ?? ''}_${endTime ?? ''}`;
      const cached = getCached(cacheKey);
      if (cached) {
        return new Response(
          JSON.stringify(cached.data),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const bParams = new URLSearchParams({
        symbol: binanceSymbol,
        interval: binanceInterval,
        limit: Math.min(1000, limit).toString(),
      });
      if (startTime) bParams.set('startTime', startTime.toString());
      if (endTime) bParams.set('endTime', endTime.toString());

      const response = await fetch(`${API_BASE}/klines?${bParams.toString()}`);
      if (!response.ok) {
        const errText = await response.text();
        return new Response(
          JSON.stringify({ error: `Binance API error (${response.status}): ${errText}` }),
          { status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const raw = await response.json() as unknown[][];
      if (!Array.isArray(raw)) {
        return new Response(
          JSON.stringify({ error: 'Unexpected Binance response format' }),
          { status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Binance returns chronological order (oldest first) — same as our internal format
      const candles = parseKlines(raw);

      setCached(cacheKey, candles);
      return new Response(
        JSON.stringify(candles),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // ---- TICKER / PRICE (current price) ----
    if (action === 'price' || action === 'quote') {
      const symbol = params.get('symbol') ?? 'BTC/USD';
      const binanceSymbol = SYMBOL_MAP[symbol] ?? 'BTCUSDT';

      const cacheKey = `price_${binanceSymbol}`;
      const cached = getCached(cacheKey);
      if (cached) {
        return new Response(
          JSON.stringify(cached.data),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const bParams = new URLSearchParams({ symbol: binanceSymbol });
      const response = await fetch(`${API_BASE}/ticker/24hr?${bParams.toString()}`);
      if (!response.ok) {
        return new Response(
          JSON.stringify({ error: `Binance API error (${response.status})` }),
          { status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const ticker = await response.json();
      const result = {
        symbol: binanceSymbol,
        price: parseFloat(ticker.lastPrice),
        open: parseFloat(ticker.openPrice),
        high: parseFloat(ticker.highPrice),
        low: parseFloat(ticker.lowPrice),
        close: parseFloat(ticker.lastPrice),
        volume: parseFloat(ticker.volume),
        priceChangePercent: parseFloat(ticker.priceChangePercent),
        timestamp: Date.now(),
      };

      setCached(cacheKey, result);
      return new Response(
        JSON.stringify(result),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ error: 'Unknown action. Use: klines, time_series, price, or quote.' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message || 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
